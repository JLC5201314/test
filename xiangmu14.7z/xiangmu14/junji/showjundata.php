<?php
header("Content-Type: text/html; charset=UTF-8");
$soldier_id=$_POST['soldier_id'];
$ID_nums=$_POST['ID_nums'];
$real_name=$_POST['real_name'];
if($soldier_id==null&&$ID_nums==null&&$real_name==null){
    echo '请输入检索条件';
}
else{
//链接数据库
@mysql_connect('localhost','root','');
//选择数据库
mysql_select_db('user');
//设置编码
mysql_query('set names utf8');
//准备sql语句
$sql="SELECT * from jun_user where soldier_id='{$soldier_id}' or ID_nums='{$ID_nums}' or real_name='{$real_name}'";
$res=mysql_query($sql);
$row=mysql_fetch_assoc($res);
if(!$row){
    echo '未检索到信息，请确认后重新输入';

}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册申请</title>
    <style>
        
    </style>
</head>
<body>
<table border="1" cellspacing="0" align="center" cellpadding="0">
				<tr>
					<th>军人证件号</th>
					<th>身份证号</th>
					<th>姓名</th>
                    <th>密码</th>
					<th>所属单位</th>
                    <th>权限</th>
                    <th>级别</th>
					<th>性别</th>
					<th>年龄</th>
                    <th>出生年月</th>
					<th>电话</th>
                    <th>住址</th>
                    <th>邮箱</th>
                   <!-- <th>审批状态</th>
                    <th>操作</th>-->
				</tr>
				<tr>
				    <td><?php echo $row['soldier_id'];?></td>
					<td><?php echo $row['ID_nums'];?></td>
					<td><?php echo $row['real_name'];?></td>
                    <td><?php echo $row['user_password'];?></td>
                    <td><?php echo $row['department'];?></td>
                    <td><?php echo $row['permission'];?></td>
					<td><?php echo $row['class'];?></td>
					<td><?php echo $row['gender'];?></td>
                    <td><?php echo $row['age'];?></td>
                    <td><?php echo $row['birth'];?></td>
                    <td><?php echo $row['tel'];?></td>
					<td><?php echo $row['user_address'];?></td>
					<td><?php echo $row['email'];?></td>
				</tr>
		</table>
</body>
</html>