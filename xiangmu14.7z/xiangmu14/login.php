<?php
  header('content-type:text/html;charset=utf-8');
  // 进行登陆校验
  // 1. 如果登录成功, 记录用户信息, 跳转个人中心页
  //    session_start();
  //    往 session 中存数据
  // 2. 如果登录失败, 提示用户登录失败, 并且跳转回登录页让用户重新登录
  //    3秒后跳转到登录页
  $soldier_id = $_POST['soldier_id'];
  $user_password = $_POST['user_password'];
  $class = $_POST['class'];//post获取级别 
    session_start();
    $passcode=$_POST['passcode'];
if( $passcode == $_SESSION['authcode']){
            //链接数据库
            $link=@mysql_connect('localhost','root','');
            mysql_select_db('user');
            mysql_query('set names utf8');
            switch($class){
                case "旅级":
                    $sq="SELECT approve from lv_signup where soldier_id='{$soldier_id}'";
                    $re=mysql_query($sq);
                    $ro=mysql_fetch_assoc($re);
                    if($ro['approve']=='已审核'||$ro==false){
                        $sql="SELECT soldier_id,user_password,permission from lv_user where soldier_id='{$soldier_id}' and user_password='{$user_password}'";
                            $res=mysql_query($sql);
                            $row=mysql_fetch_assoc($res);
                            if($row['soldier_id']==$soldier_id && $row['user_password']==$user_password)
                            {
                                $_SESSION['soldier_id']=$soldier_id;
                                $_SESSION['user_password']=$user_password;
                                $_SESSION['permission']=$row['permission'];
                                if($_SESSION['permission']=='管理员'){header("refresh:0;url=./lvji/lvji.php");}
                                else{header("refresh:0;url=./lvji/lvjiuser.php");}
                                
                            }else{
                                echo '用户名与密码不匹配';
                                echo "<script>
                                    setTimeout(function(){window.location.href='./login.html';},3000);
                                    </script>";
                            }
                        }
                        elseif($ro['approve']=='已拒绝'){
                            echo '注册未通过，请重新填写注册信息';
                            echo "<script>
                                    setTimeout(function(){window.location.href='./signup.html';},3000);
                                    </script>";
                        }elseif($ro['approve']=='待审核'){
                            echo '正在审核中，请稍后再登录';
                            echo "<script>
                                    setTimeout(function(){window.location.href='./login.html';},3000);
                                    </script>";
                        }
                            
                        break;
                        case "军级":
                            $sql="select soldier_id,user_password,permission from jun_user where soldier_id='{$soldier_id}' and user_password='{$user_password}'";
                            $res=mysql_query($sql);
                            $row=mysql_fetch_assoc($res);
                            if($row['soldier_id']==$soldier_id && $row['user_password']==$user_password)
                            {
                                $_SESSION['soldier_id']=$soldier_id;
                                $_SESSION['user_password']=$user_password;
                                $_SESSION['permission']=$row['permission'];
                                if($_SESSION['permission']=='管理员'){header("refresh:0;url=./junji/junji.php");}
                                else{header("refresh:0;url=./junji/junjiuser.php");}
                            }else{
                                echo '用户名与密码不匹配';
                                echo "<script>
                                    setTimeout(function(){window.location.href='./login.html';},3000);
                                    </script>";
                            }
                break;
                case "战区级":
                    $sql="select soldier_id,user_password,permission from zhanqu_user where soldier_id='{$soldier_id}' and user_password='{$user_password}'";
                    $res=mysql_query($sql);
                    $row=mysql_fetch_assoc($res);
                    if($row['soldier_id']==$soldier_id && $row['user_password']==$user_password)
                    {
                        $_SESSION['soldier_id']=$soldier_id;
                        $_SESSION['user_password']=$user_password;
                        $_SESSION['permission']=$row['permission'];
                        header( "location: ./zhanqu/zhanqu.php" );
                    }else{
                        echo '用户名与密码不匹配';
                        echo "<script>
                            setTimeout(function(){window.location.href='./login.html';},3000);
                            </script>";
                    }
                break;
            }
}else{
	echo '验证码输入错误,请重新输入';
	echo "<script>
	setTimeout(function(){window.location.href='./login.html';},3000);
	</script>";
}
?>

 
