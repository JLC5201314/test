<?php
//枪械类装备详情
header("Content:text/html;charset=utf8");

session_start();

@mysql_connect('localhost','root','');
mysql_select_db("weapon");
mysql_query('set names utf8');

$sql_1="SELECT firearms_name FROM firearms";
$res_1=mysql_query($sql_1);
$rows_1=array();
while($row_1=mysql_fetch_array($res_1,MYSQL_ASSOC)){
    $rows_1[]=$row_1;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>枪械数据</title>
    <link rel="stylesheet" href="../css/firearms.css">
</head>
<body>
    <div class="container1"> 
        <div class="container2"><ul class="nav">
       <li><a href="./firearms_1.php?firearms_name=<?php echo implode('',$rows_1[0]) ?>" target="myFrameName"><?php echo implode("",$rows_1[0]);?></a></li> 
        <li><a href="#" ><?php echo implode("",$rows_1[1]);?></a> </li>
        <li><a href="#" ><?php echo implode("",$rows_1[2]);?></a> </li>
         <li><a href="#" ><?php echo implode("",$rows_1[3]);?></a> </li>
        <li><a href="#" ><?php echo implode("",$rows_1[4]);?></a> </li>
        <li><a href="#" ><?php echo implode("",$rows_1[5]);?></a> </li>
         <li><a href="#" ><?php echo implode("",$rows_1[6]);?></a> </li>
         <li><a href="#" ><?php echo implode("",$rows_1[7]);?></a> </li>
         <li><a href="#" ><?php echo implode("",$rows_1[8]);?></a></li>
        <li><a href="#" ><?php echo implode("",$rows_1[9]);?></a></li>
        </ul>
     </div>
        
    <iframe id="myFrameId" name="myFrameName"  frameborder="0" src="#" scrolling="auto" ></iframe>
   
</div>
       
          
</body>
</html>