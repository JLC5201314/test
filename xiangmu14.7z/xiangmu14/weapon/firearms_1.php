<?php

$firearms_name=$_GET['firearms_name'];

@mysql_connect('localhost','root','');
mysql_select_db("weapon");
mysql_query("set names utf8");

$sql_data="SELECT * FROM firearms WHERE firearms_name='{$firearms_name}'";
//检查是否重复操作
$execute_data=mysql_query($sql_data);
$data=mysql_fetch_array($execute_data,MYSQL_ASSOC);

?>
<!--50式冲锋枪-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style type="text/css">
        .img_1{
            z-index:999;
            background-color:lightskyblue;
        }
    </style>
    
</head>
<body>
        <p style="color:red">以下信息均来自百度百科</p>
        <table border="0" cellpadding="10" cellspacing="10" style="font-size:large;">
            <tr>
                <td>
                    所属类别：<?php echo $data['weapon_type'] ?>
                </td>
            </tr>

            <tr>
                <td>
                    装备名称：<?php echo $data['firearms_name'] ?>
                    <br>
                    <img class="img_1" src="../images/50式冲锋枪.jpg" height="100" weight="150" align="left" alt="图片已丢失">
                    
                </td>
                <td>
                
                </td>
            </tr>

            <tr>
                <td>
                    现有数量：<?php echo $data['nums'] ?>
                </td>
            </tr>

            <tr>
                <td>
                    口径：枪管的内径，定义是可以塞入时正好贴紧阳膛壁的假想圆筒的直径。一般是测量两个相对的阳膛壁间的距离来断定，也就是膛径。
                </td>
            </tr>

            <tr>
                <td>
                    子弹：步枪或手枪所使用的弹药，通常包含弹头（bullet）、弹壳（case）、装药（charge）、底火（primer）四部分。散弹枪的弹药叫霰弹（shell）
                </td>
            </tr>

            <tr>
                <td>
                    弹夹：基本上一个 clip 指的是用金属框架或金属条做成，把数发子弹构成一排或交错，用以对枪枝装填弹药之用。依照其是否在装填后成为枪身的一部份，又可以分成 en block clip 和 stripper clip。
前者是金属制用来装子弹的框架，装填时整个框架连子弹一起塞入弹仓中，变成枪枝的一部份。当子弹用光时，空弹夹会自动跳出或从弹仓下方落下。它的缺点是，大部分使用这种设计的枪枝都无法在使用了一半的弹夹中装入新子弹，而且往往无法在子弹用光前将弹夹取下，造成许多困扰。这装置在19世纪由曼尼契发明，多见于曼尼契式的枪栓式步枪上，不过美国的M1 格兰特半自动步枪也是使用这类的系统。
                </td>

            </tr>

            <tr>
                <td>
                    枪身：手枪和转轮枪上最基本的结构，其他零件如枪机、枪管、弹筒等等都是加在其上。
                </td>
            </tr>

            <tr>
                <td>
                    枪体：枪械上用以把持操作的各部分，包括护木、护手、握把、后托（buttstock）等。
                </td>
            </tr>
        </table>
</body>  
</html>