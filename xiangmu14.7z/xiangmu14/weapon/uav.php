<?php
//无人机类装备详情
header("Content:text/html;charset=utf8");
@mysql_connect('localhost','root','');
mysql_select_db("weapon");
mysql_query('set names utf8');

$sql_8="SELECT uav_name FROM uav";
$res_8=mysql_query($sql_8);
$rows_8=array();
while($row_8=mysql_fetch_array($res_8,MYSQL_ASSOC)){
    $rows_8[]=$row_8;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIREARMS_DATA</title>
    <link rel="stylesheet" href="../css/weapon_data.css">
</head>
<body>
    <!--nav导航    -->
    <nav>
        <a href="#" target="myFrameName"><?php echo implode("",$rows_8[0]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[1]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[2]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[3]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[4]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[5]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[6]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[7]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[8]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_8[9]);?></a> 
    </nav>
    <div><iframe id="myFrameId" name="myFrameName"  frameborder="0" src="#" scrolling="auto" ></iframe></div>
</body>
</html>