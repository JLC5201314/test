<?php
session_start();
$soldier_id=$_SESSION['soldier_id'];
@mysql_connect('localhost','root','');
mysql_select_db("user");
mysql_query("set names utf8");
$sql="SELECT * FROM lv_user WHERE soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
$row=mysql_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户个人中心</title>
    <link rel="stylesheet" href="./css/signup.css">

</head>
<body>
    <div style="text-align: center;">
        <h1>个人信息查阅</h1>
    </div>
    
    <div>
        <table border="0" align="center" cellpadding="20" cellspacing="20" style="font-size:large;">
            <tr>
                <td>军人证件号:<?php echo $row['soldier_id'] ?></td>
                
                <!--除ie外，其他浏览器均支持number类型加减操作-->
                <td>级别:<?php echo $row['class'] ?></td>
                
            </tr>

            <tr>
                <td>所属单位：<?php echo $row['department'] ?></td>
                
            </tr>

            <tr>
                <td>姓名：<?php echo $row['real_name'] ?></td>
                
            </tr>

            <tr>
                <td>身份证号：<?php echo $row['ID_nums'] ?></td>
                
                <td>性别：<?php echo $row['gender'] ?></td>
                
            </tr>

            <tr>
                <td>家庭住址：<?php echo $row['user_address'] ?></td>
                
                <td>邮箱地址：<?php echo $row['email'] ?></td>
                
            </tr>
            
            <tr>
                <td>出生年月日：<?php echo $row['birth'] ?></td>
                 
                </td>
                <td>手机号码：<?php echo $row['tel'] ?></td>
                
            </tr>

            <tr>
                <td>密码：<?php echo $row['user_password'] ?></td>
                
                <td>用户权限：<?php echo $row['permission'] ?></td>
                               
            </tr>

            
        </table>
    </div>
</body>

</html>
