<?php
  include_once "../fn.php";
  // 作用, 判断用户是否登录, 如果未登录, 拦截到登录页
  is_login();
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="../css/lvji.css">  
  <title>旅级信息管理系统</title>
</head>
<body>
  <div class="container">
    <div> <ul class="nav">
    <li><a class="on" href="./lv-ji.php" target="myFrameName">首　　页</a></li>
    <li><a href="./query.php" target="myFrameName">查询装备</a></li>
    <span>
    <li><p>您好:<?php echo $_SESSION['soldier_id']?></p></li>
    <li><p>身份:<?php echo $_SESSION['permission']?></p></li>
    <li><a href="./usermessage.php?<?php echo $_SESSION['soldier_id']?>" target="myFrameName">个人中心</a></li>
    <li><a href="../logout.php">退出</a></li>
    </span>
  </ul>
</div></div>

<iframe id="myFrameId" name="myFrameName" scrolling="no" frameborder="0" src="lv-ji.php">
</iframe>
</body>
</html>

