<?php
header("Content-Type: text/html; charset=UTF-8");
//链接数据库
@mysql_connect('localhost','root','');
//选择数据库
mysql_select_db("weapon");
//设置编码
mysql_query('set names utf8');
//准备sql语句
$total_sql="select * from lv_weapon";
//发送sql语句
$total_res=mysql_query($total_sql);
//解析资源集
$total=mysql_num_rows($total_res);
//设置每页显示的数量
$pagesize=4;
//计算最大页码--ceil向上取整
$pagemax=ceil($total/$pagesize);
/*分页*/
//获取页码
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
//计算偏移量的方式:(当前页码-1)*每页显示的数量
$offset=($page-1)*$pagesize;
//准备sql语句
$sql="select * from lv_weapon limit {$offset},{$pagesize}";
//发送sql语句
$res=mysql_query($sql);
//解析结果集
$rows=array();
while($row=mysql_fetch_assoc($res)){
  $rows[]=$row;
}
/*<tr>
					<th colspan="5">
						<a href="./chaxun.php?page=1 & dbname=<?php echo $dbname;?>& tbname=<?php echo $tbname;?>">首页</a>
						<a href="./chaxun.php?page=<?php echo $page<=1 ? $page:$page-1;?>" >上一页</a>
						<a href="./chaxun.php?page=<?php echo $page>=$pagemax ?  $page:$page+1;?>">下一页</a>
						<a href="./chaxun.php?page=<?php echo $pagemax;?>">末页</a>
					</th>
				</tr>*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>旅级信息管理系统</title>
    <style>
        .div1{
            margin:0 auto;
            text-align:center;
        }
		h1{
            color: royalblue;
			text-align:center;
        }
	</style>
	<script src="./jsp/check.js" type="text/javascript"></script>
</head>
<body>
<div class="div1"><a href="../add/lvadddata.html">添加数据</a></div>
<table border="1" cellspacing="0" align="center">
				<tr>
					<th>序号</th>
					<th>装备名称</th>
					<th>装备数量</th>
					<th>参数特性</th>
                    <th>入库时间</th>
                    <th>操作</th>
				</tr>
				<?php foreach($rows as $v):?>
				<tr>
					<td><?php echo $v['id'];?></td>
					<td><?php echo $v['weapon_name'];?></td>
					<td><a href="#"><?php echo $v['weapon_nums'];?></a></td>
                    <td><?php echo $v['weapon_para'];?></td>
                    <td><?php echo $v['storage_date'];?></td>
					<td>
				    <a href="../update/updatedata.php?id=<?php echo $v['id']?>">修改</a>
					<a href="../delete/deletedata.php?id=<?php echo $v['id']?>">删除</a>
					<a href="../apply/lvapply.php?id=<?php echo $v['id']?>">申请</a>
					</td>
				</tr>	
				<?php endforeach;?>
				<tr>
					<th colspan="6">
						<a href="./query.php?page=1">首页</a>
						<a href="./query.php?page=<?php echo $page<=1 ? $page:$page-1;?>" >上一页</a>
						<a href="./query.php?page=<?php echo $page>=$pagemax ?  $page:$page+1;?>">下一页</a>
						<a href="./query.php?page=<?php echo $pagemax;?>">末页</a>
					</th>
				</tr>
			</table>
			<br>

</body>
</html>