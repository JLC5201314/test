<?php
header("Content-Type: text/html; charset=UTF-8");
//链接数据库
@mysql_connect('localhost','root','');
//选择数据库
mysql_select_db("weapon");
//设置编码
mysql_query('set names utf8');
//准备sql语句
$total_sql1="select * from lv_apply";
//发送sql语句
$total_res1=mysql_query($total_sql1);
//设置每页显示的数量
$pagesize=3;
//解析资源集
$total1=mysql_num_rows($total_res1);
//计算最大页码--ceil向上取整
$pagemax1=ceil($total1/$pagesize);

/*分页*/
//获取页码
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
//计算偏移量的方式:(当前页码-1)*每页显示的数量
$offset=($page-1)*$pagesize;
$sql1="select * from lv_apply limit {$offset},{$pagesize}";
//发送sql语句
$res1=mysql_query($sql1);
//解析结果集
$rows1=array();
while($row=mysql_fetch_assoc($res1)){
  $rows1[]=$row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>旅级申请</title>
    <style>
        
    </style>
</head>
<body>
    
<table border="1" cellspacing="0" align="center">
				<tr>
					<th>申请编号</th>
					<th>装备名称</th>
					<th>装备数量</th>
                    <th>申请时间</th>
					<th>审批状态</th>
                    <th>操作</th>
				</tr>
				<?php foreach($rows1 as $v):?>
				<tr>
				    <td><?php echo $v['apply_id'];?></td>
					<td><?php echo $v['weapon_name'];?></td>
					<td><?php echo $v['weapon_nums'];?></td>
                    <td><?php echo $v['apply_date'];?></td>
					<td><?php echo $v['lv_status'];?></td>
					<td>
				    <a href="../update/updateapplydata.php?apply_id=<?php echo $v['apply_id'];?>">修改</a>
					<a href="../delete/deleteapplydata.php?apply_id=<?php echo $v['apply_id'];?>">删除</a>
					</td>
				</tr>	
				<?php endforeach;?>
				<tr>
					<th colspan="6">
						<a href="./application.php.php?page=1">首页</a>
						<a href="./application.php.php?page=<?php echo $page<=1 ? $page:$page-1;?>" >上一页</a>
						<a href="./application.php.php?page=<?php echo $page>=$pagemax1 ?  $page:$page+1;?>">下一页</a>
						<a href="./application.php.php?page=<?php echo $pagemax1;?>">末页</a>
					</th>
				</tr>
			</table>
</body>
</html>