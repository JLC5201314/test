
<!DOCTYPE html>
<html>
	<head>
		<title>注册成功</title>
		<meta name="content-type"; charset=UTF-8>
	</head>
	<body>
		<div>
            <h1>注册成功！</h1>
			<a href="login.html">立即登陆</a> 
		</div>
	</body>
</html>
