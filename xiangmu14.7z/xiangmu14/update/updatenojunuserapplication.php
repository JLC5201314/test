<?php
$soldier_id=$_GET['soldier_id'];
//链接数据库
@mysql_connect('localhost','root','');
//选择数据库
mysql_select_db('user');
//设置编码
mysql_query('set names utf8');
$sql="UPDATE jun_signup set approve='已拒绝' where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
if($res){
    echo "<center>审核已拒绝</center>";
    echo "<script>
        setTimeout(function(){window.location.href='../lvji/userapplication.php';},1000);
         </script>";
    }



?>