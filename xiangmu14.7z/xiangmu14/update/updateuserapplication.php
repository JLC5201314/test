<?php
$soldier_id=$_GET['soldier_id'];
//链接数据库
@mysql_connect('localhost','root','');
//选择数据库
mysql_select_db('user');
//设置编码
mysql_query('set names utf8');
$sql="UPDATE lv_signup set approve='已审核' where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
if($res){
   $sql1="select * from lv_signup where soldier_id='{$soldier_id}'";
   $res1=mysql_query($sql1);
   $row1=mysql_fetch_assoc($res1);
   $sql1="INSERT lv_user(user_id,soldier_id,ID_nums,real_name,user_password,department,permission,class,gender,age,birth,tel,user_address,email) values(null,'{$row1['soldier_id']}','{$row1['ID_nums']}','{$row1['real_name']}','{$row1['user_password']}','{$row1['department']}','{$row1['permission']}','{$row1['class']}','{$row1['gender']}','{$row1['age']}','{$row1['birth']}','{$row1['tel']}','{$row1['user_address']}','{$row1['email']}') ";
                            $res1=mysql_query($sql1);
                            if($res1){
                                echo "<center>审核已通过，插入用户表成功</center>";
                                echo "<script>
                                setTimeout(function(){window.location.href='../lvji/userapplication.php';},1000);
                                  </script>";
                            }
   
echo "<script>
setTimeout(function(){window.location.href='../lvji/lvji.php';},3000);
</script>";

   
}else{
   echo '审核未通过';
   echo "<script>
   setTimeout(function(){window.location.href='../lvji/lvji.php';},3000);
   </script>  ";
}



?>