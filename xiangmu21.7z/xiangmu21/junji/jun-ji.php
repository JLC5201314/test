<?php
header("Content-type:text/html;charset=UTF-8");
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('weapon');
$sql="SELECT weapon_type FROM weapon_type";
$res=mysql_query($sql);
$rows=array();
//mysql_fetch_assoc可，自 PHP 5.5.0 起已废弃，并在自 PHP 7.0.0 开始被移除
while($row=mysql_fetch_array($res,MYSQL_ASSOC)){
    $rows[]=$row;
}
//print_r($rows);
//输出原数组
//echo implode("",$rows[0]);

$sql_1="SELECT firearms_name FROM firearms";
$res_1=mysql_query($sql_1);
$rows_1=array();
while($row_1=mysql_fetch_array($res_1,MYSQL_ASSOC)){
    $rows_1[]=$row_1;
}

$sql_2="SELECT ga_name FROM ga";
$res_2=mysql_query($sql_2);
$rows_2=array();
while($row_2=mysql_fetch_array($res_2,MYSQL_ASSOC)){
    $rows_2[]=$row_2;
}

$sql_3="SELECT aag_name FROM aag";
$res_3=mysql_query($sql_3);
$rows_3=array();
while($row_3=mysql_fetch_array($res_3,MYSQL_ASSOC)){
    $rows_3[]=$row_3;
}

$sql_4="SELECT spg_name FROM spg";
$res_4=mysql_query($sql_4);
$rows_4=array();
while($row_4=mysql_fetch_array($res_4,MYSQL_ASSOC)){
    $rows_4[]=$row_4;
}

$sql_5="SELECT rg_name FROM rg";
$res_5=mysql_query($sql_5);
$rows_5=array();
while($row_5=mysql_fetch_array($res_5,MYSQL_ASSOC)){
    $rows_5[]=$row_5;
}

$sql_6="SELECT missile_name FROM missile";
$res_6=mysql_query($sql_6);
$rows_6=array();
while($row_6=mysql_fetch_array($res_6,MYSQL_ASSOC)){
    $rows_6[]=$row_6;
}

$sql_7="SELECT radar_name FROM radar";
$res_7=mysql_query($sql_7);
$rows_7=array();
while($row_7=mysql_fetch_array($res_7,MYSQL_ASSOC)){
    $rows_7[]=$row_7;
}

$sql_8="SELECT uav_name FROM uav";
$res_8=mysql_query($sql_8);
$rows_8=array();
while($row_8=mysql_fetch_array($res_8,MYSQL_ASSOC)){
    $rows_8[]=$row_8;
}

$sql_9="SELECT oed_name FROM oed";
$res_9=mysql_query($sql_9);
$rows_9=array();
while($row_9=mysql_fetch_array($res_9,MYSQL_ASSOC)){
    $rows_9[]=$row_9;
}

$sql_10="SELECT ccs_name FROM ccs";
$res_10=mysql_query($sql_10);
$rows_10=array();
while($row_10=mysql_fetch_array($res_10,MYSQL_ASSOC)){
    $rows_10[]=$row_10;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <META content="MSHTML 6.00.6000.17080" name=GENERATOR>

    <link rel="stylesheet" href="../css/shouye.css">
    <link rel="stylesheet" href="../css/lvji.css">
    <SCRIPT src="../jsp/jquery-1.2.6.pack.js" type=text/javascript></SCRIPT>
    <SCRIPT src="../jsp/jquery-1.js" type=text/javascript></SCRIPT>
</head>

<body>
    <div class="container">
    <div class="block">
        <DIV class=allsort>
            <DIV class=mt>
                <STRONG><A href="#">全部装备分类</A></STRONG> </DIV>
            <DIV class=mc>
                <DIV class="item fore">
                    <SPAN>
                        <H3>
                            <A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[0]);?>
                            </A>
                        </H3>
                        <S></S>
                        <!--留白？-->
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                            <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows_1[0]);?>
                                </A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_1[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[1]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_2[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[2]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_3[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[3]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_4[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[4]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_5[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[5]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_6[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[6]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_7[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[7]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_8[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[8]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_9[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
                <DIV class="item ">
                    <SPAN>
                        <H3><A href="http://www.lanrenzhijia.com">
                                <?php echo implode("",$rows[9]);?>
                            </A></H3><S></S>
                    </SPAN>
                    <DIV class=i-mc>
                        <DIV class=subitem>
                        <DL class=fore>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[0]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[1]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[2]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[3]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[4]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[5]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[6]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[7]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[8]);?></A></DT>
                            </DL>
                            <DL>
                                <DT><A href="http://www.lanrenzhijia.com"><?php echo implode("",$rows_10[9]);?></A></DT>
                            </DL>
                        </DIV>
                    </DIV>
                </DIV>
              
                <DIV class=extra></DIV>
              
            </DIV>
        </DIV>
    </div>
    <div class="block">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius voluptatem aut commodi itaque animi mollitia architecto est accusamus quam provident, recusandae quo. Fugiat, cupiditate! Voluptas illum vitae eligendi provident harum!
    </div>
    <div class="block">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint blanditiis consectetur, ut dolorum laboriosam dolore, culpa obcaecati, enim aperiam tempora eum itaque pariatur illum magni non hic aliquam eaque beatae?
    </div>
    </div>
    
    <SCRIPT type=text/javascript>
        $(".allsort").hoverForIE6({current:"allsorthover",delay:200});
        $(".allsort .item").hoverForIE6({delay:150});
        </SCRIPT>

</body>

</html>

