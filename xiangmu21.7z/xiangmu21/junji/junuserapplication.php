<?php
header("Content-Type: text/html; charset=UTF-8");
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('weapon');
//准备sql语句
$total_sql1="select * from jun_signup";
//发送sql语句
$total_res1=mysql_query($total_sql1);
//设置每页显示的数量
$pagesize=10;
//解析资源集
$total1=mysql_num_rows($total_res1);
//计算最大页码--ceil向上取整
$pagemax1=ceil($total1/$pagesize);

/*分页*/
//获取页码
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
//计算偏移量的方式:(当前页码-1)*每页显示的数量
$offset=($page-1)*$pagesize;
$sql1="select * from jun_signup limit {$offset},{$pagesize}";
//发送sql语句
$res1=mysql_query($sql1);
//解析结果集
$rows1=array();
while($row=mysql_fetch_assoc($res1)){
  $rows1[]=$row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册申请</title>
    <style>
        
    </style>
</head>
<body>
    
<table border="1" cellspacing="0" align="center">
				<tr>
					<th>军人证件号</th>
					<th>身份证号</th>
					<th>姓名</th>
                    <th>密码</th>
					<th>所属单位</th>
                    <th>权限</th>
                    <th>级别</th>
					<th>性别</th>
					<th>年龄</th>
                    <th>出生年月</th>
					<th>电话</th>
                    <th>住址</th>
                    <th>邮箱</th>
                    <th>审批状态</th>
                    <th>操作</th>
				</tr>
				<?php foreach($rows1 as $v):?>
				<tr>
				    <td><?php echo $v['soldier_id'];?></td>
					<td><?php echo $v['ID_nums'];?></td>
					<td><?php echo $v['real_name'];?></td>
                    <td><?php echo $v['user_password'];?></td>
                    <td><?php echo $v['department'];?></td>
                    <td><?php echo $v['permission'];?></td>
					<td><?php echo $v['class'];?></td>
					<td><?php echo $v['gender'];?></td>
                    <td><?php echo $v['age'];?></td>
                    <td><?php echo $v['birth'];?></td>
                    <td><?php echo $v['tel'];?></td>
					<td><?php echo $v['user_address'];?></td>
					<td><?php echo $v['email'];?></td>
                    <td><?php echo $v['approve'];?></td>
					<td>
					<a  href="../update/updatejunuserapplication.php?soldier_id=<?php echo $v['soldier_id'];?>" onClick="{if(confirm('你真的要同意吗?')){return true;}return false;}">同意</a>
					<a  href="../update/updatenojunuserapplication.php?soldier_id=<?php echo $v['soldier_id'];?>" onClick="{if(confirm('你真的要拒绝吗?')){return true;}return false;}">不同意</a>
					<a  href="../delete/deletejunuserapplication.php?soldier_id=<?php echo $v['soldier_id'];?>" onClick="{if(confirm('你真的要删除吗?')){return true;}return false;}">删除</a>
					</td>
				</tr>	
				<?php endforeach;?>
				<tr>
					<th colspan="15">
						<a href="./junuserapplication.php?page=1">首页</a>
						<a href="./junuserapplication.php?page=<?php echo $page<=1 ? $page:$page-1;?>" >上一页</a>
						<a href="./junuserapplication.php?page=<?php echo $page>=$pagemax1 ?  $page:$page+1;?>">下一页</a>
						<a href="./junuserapplication.php?page=<?php echo $pagemax1;?>">末页</a>
					</th>
				</tr>
			</table>
</body>
</html>