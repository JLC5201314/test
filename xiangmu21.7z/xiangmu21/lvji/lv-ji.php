<?php
header("Content-type:text/html;charset=UTF-8");
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');
$sql11="SELECT * from news order by news_date DESC";
$res11=mysql_query($sql11);
$rows_11=array();
while($row_11=mysql_fetch_assoc($res11))
{
  $rows_11[]=$row_11;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <META content="MSHTML 6.00.6000.17080" name=GENERATOR>

    <link rel="stylesheet" href="../css/shouye.css">
    <SCRIPT src="../jsp/jquery-1.2.6.pack.js" type=text/javascript></SCRIPT>
    <SCRIPT src="../jsp/jquery-1.js" type=text/javascript></SCRIPT>
</head>

<body>
<div class="container">
    <div class="block style1 nav">
        <ul>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <div class="block div2 ">
        <div class="div1">
            <p>
             <a class="a1" href="./addnews.html" target="_blank">添加公告</a>
            </p>
            
        <span>
            <?php foreach($rows_11 as  $value): ?>
            <ul>
                <li><a href="./newsdetails.php?id=<?php echo $value['id'] ?>"
                        target="_blank"><?php echo $value['title'] ?></a></li>
            </ul>
            <?php endforeach; ?>
        </span>
        </div>
    </div>
    <div class="block">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint blanditiis consectetur, ut dolorum laboriosam dolore, culpa obcaecati, enim aperiam tempora eum itaque pariatur illum magni non hic aliquam eaque beatae?
    </div>
</div>
    <SCRIPT type=text/javascript>
        $(".allsort").hoverForIE6({current:"allsorthover",delay:200});
        $(".allsort .item").hoverForIE6({delay:150});
  </SCRIPT>
    
</body>

</html>

