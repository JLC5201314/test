<?php
header("Content-Type: text/html; charset=UTF-8");
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
//准备sql语句
$total_sql1="select * from lv_signup";
//发送sql语句
$total_res1=mysql_query($total_sql1);
//设置每页显示的数量
$pagesize=10;
//解析资源集
$total1=mysql_num_rows($total_res1);
//计算最大页码--ceil向上取整
$pagemax1=ceil($total1/$pagesize);

/*分页*/
//获取页码
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
//计算偏移量的方式:(当前页码-1)*每页显示的数量
$offset=($page-1)*$pagesize;
$sql1="select * from lv_signup order by user_id limit {$offset},{$pagesize}";
//发送sql语句
$res1=mysql_query($sql1);
if(mysql_num_rows($res1)==0){
	header("location:./empty.php");
}
//解析结果集
$rows1=array();
while($row=mysql_fetch_assoc($res1)){
  $rows1[]=$row;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>注册申请</title>
	<script src="../jsp/jquery.js"></script>
	<script src="../jsp/jquery.min.js"></script>
	<style type="text/css">
		td {
			word-break: nowrap;
			/* 不换行 word-break: keep-all;换行 work-break:nowrap*/
			overflow: hidden;
			/* 内容超出宽度时隐藏超出部分的内容 */
			text-overflow: ellipsis;
			text-align:center;
			/* 当对象内文本溢出时显示省略标记(...) ；需与overflow:hidden;一起使用。*/
		}
		.class1{
			width:35px;
		}
		.class2{
			width:70px;
		}
		.class3{
			width:85px;
		}
		.class4{
			width:110px;
		}
		.class5{
			width:150px;
		}
		.class6{
			width:300px;
		}
		div{
			margin-top:20px;
		}
	</style>
</head>

<body>
	<div>
		<table border="1" cellspacing="0" align="center" style="font-size:medium;">
			<tr>
			    <th class="class3">军人证件号</th>
				<th class="class4">身份证号</th>
				<th class="class2">姓名</th>
				<th class="class4">密码</th>
				<th class="class4">所属单位</th>
				<th class="class2">权限</th>
				<th class="class1">级别</th>
				<th class="class1">性别</th>
				<th class="class1">年龄</th>
				<th class="class3">出生年月</th>
				<th class="class4">电话</th>
				<th class="class5">住址</th>
				<th>邮箱</th>
				<th>审批状态</th>
				<th>操作</th>
			</tr>
			<?php foreach($rows1 as $v):?>
			<tr>
			<td class="class3"><?php echo $v['soldier_id'];?></td>
				<td class="class4"><?php echo $v['ID_nums'];?></td>
				<td class="class2"><?php echo $v['real_name'];?></td>
				<td class="class4"><?php echo $v['user_password'];?></td>
				<td class="class4"><div title="<?php echo $v['department']?>" class="title"><?php echo $v['department'];?></div></td>
				<td class="class2"><?php echo $v['permission'];?></td>
				<td class="class1"><?php echo $v['class'];?></td>
				<td class="class1"><?php echo $v['gender'];?></td>
				<td class="class1"><?php echo (date('Y')-substr($v['birth'],0,4));?></td><!--无法精准到月份-->
				<td class="class3"><?php echo $v['birth'];?></td>
				<td class="class4"><?php echo $v['tel'];?></td>
				<td class="class5"><div title="<?php echo $v['user_address']?>" class="title"><?php echo $v['user_address'];?></div></td>
				<td><div title="<?php echo $v['email']?>" class="title"><?php echo $v['email'];?></div></td>
				<td><?php echo $v['approve'];?></td>
				<td>
					<a href="../update/updateuserapplication.php?soldier_id=<?php echo $v['soldier_id'];?>"
						onClick="{if(confirm('你真的要同意吗?')){return true;}return false;}">同意</a>
					<a href="../update/updatenouserapplication.php?soldier_id=<?php echo $v['soldier_id'];?>"
						onClick="{if(confirm('你真的要拒绝吗?')){return true;}return false;}">不同意</a>
					<a href="../delete/deleteuserapplication.php?soldier_id=<?php echo $v['soldier_id'];?>"
						onClick="{if(confirm('你真的要删除吗?')){return true;}return false;}">删除</a>
				</td>
			</tr>
			<?php endforeach;?>
			<tr>
				<th colspan="15">
					<a href="./userapplication.php?page=1">首页</a>
					<a href="./userapplication.php?page=<?php echo $page<=1 ? $page:$page-1;?>">上一页</a>
					<a href="./userapplication.php?page=<?php echo $page>=$pagemax1 ?  $page:$page+1;?>">下一页</a>
					<a href="./userapplication.php?page=<?php echo $pagemax1;?>">末页</a>
				</th>
			</tr>
		</table>
	</div>
	<script type="text/javascript">
		$(function () {
			$("table th").css("background", "lightgray")
			$("table tr:nth-child(odd)").css("background", "lightblue")
		})
	</script>
</body>

</html>