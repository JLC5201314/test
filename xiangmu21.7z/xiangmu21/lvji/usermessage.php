<?php
header('content-type:text/html;charset=utf-8');
session_start();
$soldier_id=$_SESSION['soldier_id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
$sql="SELECT * FROM lv_user WHERE soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
$row=mysql_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户个人中心</title>
    <link rel="stylesheet" href="./css/signup.css">
    <style type="text/css">
         button{
     display: inline-block;
     outline: none;
     cursor: pointer;
     text-align: center;
     text-decoration: none;
     width:100px;
     font: 20px/100% Arial, Helvetica, sans-serif;
     padding: 10px;
     text-shadow: 0 1px 1px rgba(0,0,0,.3);
     -webkit-border-radius: 5px; 
     -moz-border-radius: 5px;
     border-radius: 5px;
     -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);
     -moz-box-shadow: 0 1px 2px rgba(0,0,0,.2);
     box-shadow: 0 1px 2px rgba(0,0,0,.2);
     color: #d9eef7;
     border: solid 1px #0076a3;
     background: #0095cd;
     background: -webkit-gradient(linear, left top, left bottom, from(#0095cc), to(#00678e));
     background: -moz-linear-gradient(top, #00adee, #00678e);
     filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00adee', endColorstr='#00678e');
 }
 button:hover{
     background: #007ead;
     background: -webkit-gradient(linear, left top, left bottom, from(#00678e), to(#0095cc));
     background: -moz-linear-gradient(top, #00678e, #0095cc);
     filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00678e', endColorstr='#0095cc');
 }
    </style>
</head>
<body>
    <div style="text-align: center;">
        <h1>个人信息查阅</h1>
    </div>
    
    <div>
        <table border="0" align="center" cellpadding="15" cellspacing="15" style="font-size:large;">
            <tr>
                <td>军人证件号:<?php echo $row['soldier_id'] ?></td>
                
                <!--除ie外，其他浏览器均支持number类型加减操作-->
                <td>级别:<?php echo $row['class'] ?></td>
                
            </tr>

            <tr>
                <td>所属单位：<?php echo $row['department'] ?></td>
                
            </tr>

            <tr>
                <td>姓名：<?php echo $row['real_name'] ?></td>
                
            </tr>

            <tr>
                <td>身份证号：<?php echo $row['ID_nums'] ?></td>
                
                <td>性别：<?php echo $row['gender'] ?></td>
                
            </tr>

            <tr>
                <td>家庭住址：<?php echo $row['user_address'] ?></td>
                
                <td>邮箱地址：<?php echo $row['email'] ?></td>
                
            </tr>
            
            <tr>
                <td>出生年月日：<?php echo $row['birth'] ?></td>
                 
                </td>
                <td>手机号码：<?php echo $row['tel'] ?></td>
                
            </tr>

            <tr>
                <td>密码：<?php echo $row['user_password'] ?></td>
                
                <td>用户权限：<?php echo $row['permission'] ?></td>
                               
            </tr>
            <tr >
            <td colspan="2" align="center"> <a href="../update/updateuser.php?soldier_id=<?php echo $row['soldier_id'];?>"><button>修改</button></a></td>
            </tr>
            
        </table>
    </div>
</body>

</html>
