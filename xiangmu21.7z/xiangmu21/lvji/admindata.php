<?php
header("Content-Type: text/html; charset=UTF-8");
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
//准备sql语句
$total_sql1="select * from lv_user";
//发送sql语句
$total_res1=mysql_query($total_sql1);
//设置每页显示的数量
$pagesize=10;
//解析资源集
$total1=mysql_num_rows($total_res1);
//计算最大页码--ceil向上取整
$pagemax1=ceil($total1/$pagesize);

/*分页*/
//获取页码
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
//计算偏移量的方式:(当前页码-1)*每页显示的数量
$offset=($page-1)*$pagesize;
$sql1="select * from lv_user limit {$offset},{$pagesize}";
//发送sql语句
$res1=mysql_query($sql1);
//解析结果集
$rows1=array();
while($row=mysql_fetch_assoc($res1)){
  $rows1[]=$row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>查询用户</title>
    <link rel="stylesheet" href="../css/admindata.css">  
    <script src="../jsp/jquery.js"></script>
	<script src="../jsp/jquery.min.js"></script>
	<style type="text/css">
		td{word-break:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}
		.class1{
			width:50px;
		}
		.class2{
			width:70px;
		}
		.class3{
			width:85px;
		}
		.class4{
			width:110px;
		}
		.class5{
			width:170px;
		}
		.class6{
			width:250px;
		}
		table tr>td{
			text-align:center;
		}
		#title{
			position:absolute;
			font-size:large;
			border:1px solid #d2d2d2;
			background-color:white;
			display:none;
		}
		table tr>td{
			text-align:center;
		}
		#title{
			position:absolute;
			font-size:large;
			border:1px solid #d2d2d2;
			background-color:white;
			display:none;
		}
		h2{
			text-align:center;
			color:lightblue;
		}
		div{
			margin-top:5px;
			margin-bottom:10px;
		}
		.form1{
			margin-top:10px;
			margin-bottom:20px;
			text-align:center;
		}
		input{
			margin:10px;
		}
		.button1 {
			padding-left:20px;
			padding-right:20px;
			padding-bottom:20px;
			height: 40px;
			line-height: 40px;
			text-align: center;
			background-color:lightblue;
			font-size: large;
			font-family: Arial, Helvetica, sans-serif;
			color: black;
			border: 1px solid lightblue;
			background-color:transparent;
			border-radius:5px;
			cursor: pointer;
        }
		select{
			padding:9px;
			border-radius:5px;
			border:1px solid lightblue;
			background-color:transparent;
		}
		.div3{
			margin-left:2%;
			margin-right:2%;
			margin-top:1%;
		}
		.div4{
			margin-top:1%;
		}
	</style>
</head>
<body>
	<div class="div4"><h2>请输入检索条件</h2></div>
<form action="./showdata.php" method="POST" target="FrameName" class="form1">
				<select name="model">
                    <option  value="模糊查询">模糊查询</option>
                    <option  value="精准查询">精准查询</option>
                </select><br>       
	  军人证件号:<input type="text" name="soldier_id">
	  姓名:<input type="text" name="real_name">
	  权限:<input type="text" name="permission"><br>
	  性别:<input type="text" name="gender">
	  起始出生年月:<input  type="text" name="begin_birth" size="25" placeholder="YYYY-MM-DD" id="test1"/>
	  结束出生年月:<input  type="text" name="end_birth" size="25" placeholder="YYYY-MM-DD" id="test2"/>
	  <input type="submit" name="检索" value="检索" class="button1"/>
    </form>
	
<iframe src="./admindatatb.php" frameborder="0"width="100%" height="400px" name="FrameName" class="iframe"></iframe>
<script type="text/javascript">
   $(function(){
	   $("table th").css("background","lightgray")
	   $("table tr:nth-child(odd)").css("background","lightblue")
   })

</script>
<script src="../laydate/laydate.js"></script> <!-- 改成你的路径 -->
    <script>
    lay('#version').html('-v'+ laydate.v);
    
    //执行一个laydate实例
    laydate.render({
      elem: '#test1' //指定元素
    });
	</script>
	<script src="../laydate/laydate.js"></script> <!-- 改成你的路径 -->
    <script>
    lay('#version').html('-v'+ laydate.v);
    
    //执行一个laydate实例
    laydate.render({
      elem: '#test2' //指定元素
    });
    </script>

<!--<script>
	$(function(){
		var x = 1;
		var y = 1;
		$("div.title").mouseover(
			function(e){
				this.myTitle = this.title;//获取默认的title
				this.title="";//清空默认的title
				var title="<div id='title'>" + this.myTitle + "<\/div>";//创建新的div元素，在css样式已定义样式
				$("body").append(title);//把它追加到文档中
				$("#title").css({
					"top":(e.pageY ) + "px",
					"left":(e.pageX) + "px"
				}).show("fast");//设置x，y的坐标，并且快速显示
			}).mouseout(
			function(){
				this.title=this.myTitle;
				$("#title").remove();//光标离开时移除
			})
	})
</script>-->
</body>
</html>