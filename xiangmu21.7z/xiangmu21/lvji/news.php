<?php
header('content-type:text/html;charset=utf-8');
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');
$total_sql="SELECT * from news order by news_date DESC";
$total_res=mysql_query($total_sql);
$total=mysql_num_rows($total_res);
//设置每页显示的数量
$pagesize=5;
//计算最大页码--ceil向上取整
$pagemax=ceil($total/$pagesize);
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
$offset=($page-1)*$pagesize;

$sql="SELECT * from news  order by news_date DESC limit {$offset},{$pagesize}";
$res=mysql_query($sql);
$rows=array();
while($row=mysql_fetch_assoc($res))
{
  $rows[]=$row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公告修改</title>
    <script src="../jsp/jquery.js"></script>
    <script src="../jsp/jquery.min.js"></script>
    <style type="text/css">
        .class1{
            width:320px;
        }
        td{
            text-align:center;
        }
        div{
            margin:0 auto;
            text-align:center;
            margin-top:8%;
        }
        a{
            text-decoration:none;
        }
        a:hover {
            background-color:lightblue;
            border-radius:5px;
       }
       a:visited{
           background-color:lightskyblue;
       }
    </style>
</head>
<body>
<div><h2><a href="../news/addnews.html">添加公告</a></h2></div>
        <table border="1" align="center" cellpadding="10" cellspacing="0" style="font-size:large;">
        <tr>
            <th>
            公告标题
            </th>
            <th>
            操作
            </th>
        </tr>
        <?php foreach($rows as $v):?>
        <tr>
        <td class="class1"><?php echo $v['title']?></td>
        <td>&nbsp;&nbsp;&nbsp;<a href="../news/updatenews.php?id=<?php echo $v['id']?>">修改</a>&nbsp;&nbsp;&nbsp;<a href="../news/deletenews.php?id=<?php echo $v['id']?>" onclick="{if(confirm('你真的要删除吗？')){return ture;}return false;}">删除</a>
        </td>
        </tr>
        <?php endforeach;?>
        <tr>
        <td colspan="2">
        <a href="./news.php?page=1">首页</a>
        <a href="./news.php?page=<?php echo $page<=1?$page:$page-1?>">上一页</a>
        <a href="./news.php?page=<?php echo $page>=$pagemax?$page:$page+1;?>">下一页</a>
        <a href="./news.php?page=<?php echo $pagemax;?>">末页</a>
        </td>
        </tr>
        </table>
    <script>
        $("table th").css("background","lightskyblue")
        $("table tr:nth-child(odd)").css("background","lightblue")
    </script>
</body>
</html>