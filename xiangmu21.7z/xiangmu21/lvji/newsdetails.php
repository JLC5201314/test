<?php
$id=$_GET['id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');
$get_content="SELECT * FROM news WHERE id='{$id}'";
$execute=mysql_query($get_content);
$res=mysql_fetch_assoc($execute);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公告详情</title>
    <script src="../jsp/jquery.min.js"></script>
    <style type="text/css"> 
       body{
           font-size:large;
           background-color:lightgray;
       }
       div{
           margin-left:60px;
           margin-right:60px;
           margin-top:20px;
           margin-bottom:20px;
           text-align:center;
           height:40px;
           line-height:40px;
           
       }
        h2{
            color:skyblue;
            font-weight: bold;
        }
        .div1{
            text-align:left;
        }
        .container{
            width:85%;
            margin:0 auto;
        }
        .style1{
            font-weight:bold;
        }
        pre {
white-space: pre-wrap;       /* css-3 */
white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */
white-space: -pre-wrap;      /* Opera 4-6 */
white-space: -o-pre-wrap;    /* Opera 7 */
word-wrap: break-word;       /* Internet Explorer 5.5+ */
word-break:break-all;
overflow:hidden;
}
    </style>
    
</head>
<body>
    <div class="container">
     
          <h2>公告内容</h2>
            <div class="style1"> 通告标题: <?php echo $res['title'] ?></div>
            <div class="style1">通知类型: <?php echo $res['news_class'] ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 发布时间: <?php echo $res['news_date'] ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;信息来源: <?php echo $res['resource'] ?></div>    
            <div class="div1"> 主体内容：<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $res['main_content'] ?></div>
    </div>
   
</body>
</html>