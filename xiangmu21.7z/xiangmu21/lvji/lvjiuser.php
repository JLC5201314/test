<?php
header('content-type:text/html;charset=utf-8');
  include_once "../fn.php";
  // 作用, 判断用户是否登录, 如果未登录, 拦截到登录页
  is_login();
  /* */
  /* */
  include_once "../connect.php";
  // 作用, 链接数据库
  connect_mysql();
  mysql_select_db('news');
$sql="SELECT * from news order by news_date DESC";
$res=mysql_query($sql);
$rows=array();
while($row=mysql_fetch_assoc($res))
{
  $rows[]=$row;
}
mysql_select_db("ordnance");
mysql_query("set names utf8");
$sql1="select * from 东001手枪 order by ordnanceID";
$res1=mysql_query($sql1);
$rows1=array();
while($row1=mysql_fetch_assoc($res1)){
  $rows1[]=$row1;
}
mysql_select_db("ordnance");
mysql_query("set names utf8");
$sql2="select * from 东001步枪 order by ordnanceID";
$res2=mysql_query($sql2);
$rows2=array();
while($row2=mysql_fetch_assoc($res2)){
  $rows2[]=$row2;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="../css/lvji.css">  
  <script src="../jsp/jquery.min.js"></script>
 
  <title>旅级信息管理系统</title>
  <style type="text/css">
    .p1{
      font-weight:bolder;
      font-size:large;
      letter-spacing:0.4em;
      height:60px;
      line-height:60px;
    }
    .p2{
      font-size:medium;
      letter-spacing:0.2em;
      height:60px;
      line-height:60px;
    }
    .menuone{
      margin-left:20px;
      padding:5px;
      color:blue;
      font-size:large;
      cursor:pointer;
    }
    .menutwo li{
      padding:3px;
      color:white;
      font-size:large;
      margin-left:20px;
    }
    .menu{
      padding:5px;
      font-size:large;
    }
  button{
     display: inline-block;
     outline: none;
     cursor: pointer;
     text-align: center;
     text-decoration: none;
     width:100px;
     font: 20px/100% Arial, Helvetica, sans-serif;
     padding: 5px 2px 4px;
     text-shadow: 0 1px 1px rgba(0,0,0,.3);
     -webkit-border-radius: 5px; 
     -moz-border-radius: 5px;
     border-radius: 5px;
     -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);
     -moz-box-shadow: 0 1px 2px rgba(0,0,0,.2);
     box-shadow: 0 1px 2px rgba(0,0,0,.2);
     color: #d9eef7;
     border: solid 1px #0076a3;
     background: #0095cd;
     background: -webkit-gradient(linear, left top, left bottom, from(#0095cc), to(#00678e));
     background: -moz-linear-gradient(top, #00adee, #00678e);
     filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00adee', endColorstr='#00678e');
 }
 button:hover{
     background: #007ead;
     background: -webkit-gradient(linear, left top, left bottom, from(#00678e), to(#0095cc));
     background: -moz-linear-gradient(top, #00678e, #0095cc);
     filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00678e', endColorstr='#0095cc');
 }
.u13 li{
  padding:5px;
  margin-top:10px;
  list-style:none;
}
.div3{
  text-align:center;
}
  </style>
</head>
<body>
  <ul class="nav ">
    <li><a class="on" href="#">首　　页</a></li>
  <!--  <li><a href="../tablesql/showtable.php" target="myFrameName">查询装备</a></li>
    <li><a href="./userapplication.php" target="myFrameName">审批</a></li>
    <li><a href="./admindata.php" target="myFrameName">查询</a></li>-->
    <li><p class="p1">基于物联网的军械装备管理系统</p></li>
    <span >
    <li><p class="p2">您好:<?php echo $_SESSION['soldier_id']?></p></li>
    <li><p class="p2">身份:<?php echo $_SESSION['permission']?></p></li>
    <li><a href="./usermessage.php?<?php echo $_SESSION['soldier_id']?>" target="myFrameName">个人中心</a></li>
    <li><a href="../logout.php" onClick="{if(confirm('你真的要退出吗?')){return true;}return false;}">退出</a></li>
    </span>
  </ul>
<div>
  <div class="block1">
    <div class="div-margin">
      <ul class="ul1">
      <li class="menu"><a href="../weapon/weapon_data.php" target="_blank">装备名称</a></li> 
      <li class="menuone">手枪
        <ul class="menutwo">
        <?php foreach($rows1 as $v):?>
          <li>
           <a href="../weapon/weapon_data.php" target="_blank"><?php echo $v['名称型号']?></a> 
          </li>
      <?php endforeach;?>
        </ul>
      </li>
      <li class="menuone">步枪
          <ul class="menutwo">
          <?php foreach($rows2 as $v):?>
            <li>
            <a href="../weapon/weapon_data.php" target="_blank"><?php echo $v['名称型号']?></a> 
            </li>
            <?php endforeach;?>
          </ul>
      </li>
      <li class="menuone">

      </li>
    </ul>
    </div>
    
  </div>
  <div class="block2">
      <div class="div1">
          <!--<p>
           <a class="a1" href="./addnews.html" target="_blank">添加公告</a>
          </p>-->
          
      <span>
          <?php foreach($rows as  $value): ?>
          <ul class="nav2">
              <li><a href="./newsdetails.php?id=<?php echo $value['id'] ?>"
                      target="_blank"><?php echo $value['title'] ?></a></li>
          </ul>
          <?php endforeach; ?>
      </span>
      </div>
  </div>
  <div class="block3">
    <div class="div3">
      <ul class="u13">
          <li><a href="./userapplication.php" target="_blank"><button>审批用户</button></a></li>
          <li><a href="../tablesql/showtable.php" target="_blank"><button>查询装备</button></a></li>
          <li><a href="./admindata.php" target="_blank"><button>查询用户</button></a></li>
          <li><a href="./admindatatb.php" target="_blank"><button>修改用户</button></a></li>
        </ul>  
    </div>
            
  </div>
 </div>
<!--
  <div class="pad"></div>
  <iframe id="myFrameId" name="myFrameName" scrolling="auto" frameborder="0" src="lv-ji.php">
  </iframe>-->
  <script type="text/javascript">
    $(".menuone").click(function(){
      $(this).children("ul").slideToggle();
    })
  </script>

</body>
</html>

