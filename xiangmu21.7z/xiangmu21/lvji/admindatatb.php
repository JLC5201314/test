<?php
header("Content-Type: text/html; charset=UTF-8");
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
//准备sql语句
$total_sql1="select * from lv_user";
//发送sql语句
$total_res1=mysql_query($total_sql1);
//设置每页显示的数量
$pagesize=10;
//解析资源集
$total1=mysql_num_rows($total_res1);
//计算最大页码--ceil向上取整
$pagemax1=ceil($total1/$pagesize);

/*分页*/
//获取页码
$page=isset($_GET['page'])?$_GET['page']:1;
//偏移量
//计算偏移量的方式:(当前页码-1)*每页显示的数量
$offset=($page-1)*$pagesize;
$sql1="select * from lv_user limit {$offset},{$pagesize}";
//发送sql语句
$res1=mysql_query($sql1);
//解析结果集
$rows1=array();
while($row=mysql_fetch_assoc($res1)){
  $rows1[]=$row;
}
/*<div title="点击可修改个人信息" class="title"><a href="../update/upuser.php?soldier_id=<?php echo $v['soldier_id'];?>" ></a></div>*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户信息</title>
    <link rel="stylesheet" href="../css/admindata.css">  
    <script src="../jsp/jquery.js"></script>
	<script src="../jsp/jquery.min.js"></script>
	<style type="text/css">
		td{word-break:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}
		.class1{
			width:50px;
		}
		.class2{
			width:70px;
		}
		.class3{
			width:85px;
		}
		.class4{
			width:110px;
		}
		.class5{
			width:170px;
		}
		.class6{
			width:250px;
		}
		table tr>td{
			text-align:center;
		}
		#title{
			position:absolute;
			font-size:medium;
			border:1px solid lightblue;
			background-color:white;
			display:none;
			color:lightskyblue;
		}
		h2{
			text-align:center;
			color:lightblue;
		}
		div{
			text-align:center;
			margin-left:1%;
			margin-right:1%;
		}
	</style>
</head>
<body>
<div>  <table border="1" cellspacing="0" cellpadding="10" align="center" style="font-size:medium;" class="table1">
			<tr>
				<th class="class3">军人证件号</th>
				<th class="class4">身份证号</th>
				<th class="class1">姓名</th>
				<th class="class4">密码</th>
				<th class="class5">所属单位</th>
				<th class="class2">权限</th>
				<th class="class1">级别</th>
				<th class="class1">性别</th>
				<th class="class1">年龄</th>
				<th class="class3">出生年月</th>
				<th class="class4">电话</th>
				<th class="class6">住址</th>
				<th>邮箱</th>
			    <th>操作</th>
			</tr>
			<?php foreach($rows1 as $v):?>
			<tr>
				<td class="class3"><?php echo $v['soldier_id'];?></td>
				<td class="class4"><?php echo $v['ID_nums'];?></td>
				<td class="class1"><?php echo $v['real_name'];?></td>
				<td class="class4"><?php echo $v['user_password'];?></td>
				<td class="class5"><?php echo $v['department'];?></td>
				<td class="class2"><?php echo $v['permission'];?></td>
				<td class="class1"><?php echo $v['class'];?></td>
				<td class="class1"><?php echo $v['gender'];?></td>
				<td class="class1"><?php echo (date('Y')-substr($v['birth'],0,4));?></td><!--无法精准到月份-->
				<td class="class3"><?php echo $v['birth'];?></td>
				<td class="class4"><?php echo $v['tel'];?></td>
				<td class="class6"><?php echo $v['user_address'];?></td>
				<td><?php echo $v['email'];?></td>
				<td>
				    <a href="../update/upuser.php?soldier_id=<?php echo $v['soldier_id'];?>">修改</a>
					<a href="../delete/deleteuser.php?soldier_id=<?php echo $v['soldier_id'];?>" onClick="{if(confirm('你真的要删除吗?')){return true;}return false;}">删除</a>
				</td>
			</tr>
			<?php endforeach;?>
			<tr>
				<th colspan="14">
					<a href="./admindatatb.php?page=1">首页</a>
					<a href="./admindatatb.php?page=<?php echo $page<=1 ? $page:$page-1;?>">上一页</a>
					<a href="./admindatatb.php?page=<?php echo $page>=$pagemax1 ?  $page:$page+1;?>">下一页</a>
					<a href="./admindatatb.php?page=<?php echo $pagemax1;?>">末页</a>
				</th>
			</tr>
</table>
</div>
  
<script type="text/javascript">
   $(function(){
	   $("table th").css("background","lightgray")
	   $("table tr:nth-child(odd)").css("background","lightblue")
   })

</script>
<script src="../laydate/laydate.js"></script> <!-- 改成你的路径 -->
    <script>
    lay('#version').html('-v'+ laydate.v);
    
    //执行一个laydate实例
    laydate.render({
      elem: '#test1' //指定元素
    });
	</script>
	<script src="../laydate/laydate.js"></script> <!-- 改成你的路径 -->
    <script>
    lay('#version').html('-v'+ laydate.v);
    
    //执行一个laydate实例
    laydate.render({
      elem: '#test2' //指定元素
    });
    </script>

<script>
		var x = 1;
		var y = 1;
		$(".title").mouseover(
			function(e){
				this.myTitle = this.title;//获取默认的title
				this.title="";//清空默认的title
				var title="<div id='title'>" + this.myTitle + "<\/div>";//创建新的span元素，在css样式已定义样式
				$("body").append(title);//把它追加到文档中
				$("#title").css({
					"top":(e.pageY ) + "px",
					"left":(e.pageX) + "px"
				}).show();//设置x，y的坐标，并且快速显示
			}).mouseout(
			function(){
				this.title=this.myTitle;
				$("#title").remove();//光标离开时移除
			})
	
</script>
</body>
</html>
