<?php
header("Content-Type: text/html; charset=UTF-8");
$model=$_POST['model'];
$soldier_id=$_POST['soldier_id'];
$real_name=$_POST['real_name'];
$gender=$_POST['gender'];
$permission=$_POST['permission'];
$begin=$_POST['begin_birth'];
$end=$_POST['end_birth'];
if($soldier_id==null&&$gender==null&&$real_name==null&&$begin==null&&$end==null&&$permission==null){
    echo "<script>alert('请输入检索条件')</script>";
    echo "<script>
 window.location.href='./empty.php';
      </script>";
    }
else{
    include_once "../connect.php";
    // 作用, 链接数据库
    connect_mysql();
    mysql_select_db('user');
switch($model){
    case "模糊查询":
        //准备sql语句
        $sql="SELECT * from lv_user where soldier_id='{$soldier_id}' or gender='{$gender}' or real_name='{$real_name}' or permission='{$permission}' or birth between '{$begin}' and '{$end}'";
        $res=mysql_query($sql);
        $rows=array();
        while(($row=mysql_fetch_assoc($res)))
        {
            $rows[]=$row;
        }
        if(mysql_num_rows($res)==0){
            header("location:./empty.php");
        }
    break;
    case "精准查询":
        if($soldier_id==null){
            $soldier_id="soldier_id";
        }else{
            $soldier_id="'{$soldier_id}'";
        }
        if($real_name==null){
            $real_name="real_name";
        }else{
            $real_name="'{$real_name}'";
        }
        if($gender==null){
            $gender="gender";
        }else{
            $gender="'{$gender}'";
        }
        if($permission==null){
            $permission="permission";
        }else{
            $permission="'{$permission}'";
        }
        if($begin==null){
            $begin="birth";
        }else{
            $begin="'{$begin}'";
        }
        if($end==null){
            $end="birth";
        }else{
            $end="'{$end}'";
        }
        //准备sql语句
        $sql="SELECT * from lv_user where soldier_id= $soldier_id and gender=$gender and permission=$permission and real_name=$real_name and birth between $begin and $end";
        $res=mysql_query($sql);
        $rows=array();
        while(($row=mysql_fetch_assoc($res)))
        {
            $rows[]=$row;
        }
        if(mysql_num_rows($res)==0){
            header("location:./empty.php");
        }
    break;
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>搜索信息</title>
    <script src="../jsp/jquery.js"></script>
    <script src="../jsp/jquery.min.js"></script>
   <style type="text/css">
       td{word-break:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center !important}
       .div1{
           margin:0 auto;
           text-align:right;
       }
       .class1{
			width:50px;
		}
		.class2{
			width:70px;
		}
		.class3{
			width:85px;
		}
		.class4{
			width:110px;
		}
		.class5{
			width:170px;
		}
		.class6{
			width:300px;
		}
    </style>
</head>
<body>
    <div id="dayin">
    <!--startprint-->
         <table border="1" cellspacing="0" align="center" cellpadding="0">
				<tr>
                <th class="class3">军人证件号</th>
				<th class="class4">身份证号</th>
				<th class="class1">姓名</th>
				<th class="class4">密码</th>
				<th class="class5">所属单位</th>
				<th class="class3">权限</th>
				<th class="class1">级别</th>
				<th class="class1">性别</th>
				<th class="class1">年龄</th>
				<th class="class3">出生年月</th>
				<th class="class4">电话</th>
				<th class="class6">住址</th>
				<th>邮箱</th>
                   <!-- <th>审批状态</th>
                    <th>操作</th>-->
                </tr>
                <?php if($rows) foreach($rows as $key=> $v):?>
				<tr>
                <td class="class3"><?php echo $v['soldier_id'];?></td>
				<td class="class4"><?php echo $v['ID_nums'];?></td>
				<td class="class1"><?php echo $v['real_name'];?></td>
				<td class="class4"><?php echo $v['user_password'];?></td>
				<td class="class5"><div title="<?php echo $v['department']?>" class="title"><?php echo $v['department'];?></div></td>
				<td class="class3"><?php echo $v['permission'];?></td>
				<td class="class1"><?php echo $v['class'];?></td>
				<td class="class1"><?php echo $v['gender'];?></td>
				<td class="class1"><?php echo (date('Y')-substr($v['birth'],0,4));?></td><!--无法精准到月份-->
				<td class="class3"><?php echo $v['birth'];?></td>
				<td class="class4"><?php echo $v['tel'];?></td>
				<td class="class6"><div title="<?php echo $v['user_address']?>" class="title"><?php echo $v['user_address'];?></div></td>
				<td><div title="<?php echo $v['email']?>" class="title"><?php echo $v['email'];?></div></td>
                </tr>
                <?php endforeach;?>
        </table>
        <!--endprint-->
    </div>
    <div class="div1"><button>打印</button></div>
    <iframe id="iframe1" style="display: none"></iframe>
<script type="text/javascript">
$(function(){
    $("table th").css("background","lightblue")
    $("table tr:nth-child(odd)").css("background","lightblue")
})
</script> 
    
</body>
<script type="text/javascript">
         $("button").click(function(){
            bdhtml=$("#dayin").html();
            //alert(bdhtml);
            sprnstr="<!--startprint-->";   //开始打印标识字符串有17个字符
            eprnstr="<!--endprint-->";        //结束打印标识字符串
            prnhtml=bdhtml.substr(bdhtml.indexOf(sprnstr)+17); //从开始打印标识之后的内容
            prnhtml=prnhtml.substring(0,prnhtml.indexOf(eprnstr));//截取开始标识和结束标识之间的内容
            var iframe = null;
            iframe = document.getElementById("iframe1")
            
            var iwindow = null;
            var iwindow = iframe.contentWindow;//获取iframe的window对象
            iwindow.document.close();
            iwindow.document.write(prnhtml);
            iwindow.print(); //调用浏览器的打印功能打印指定区域
        });
    </script>

</html>