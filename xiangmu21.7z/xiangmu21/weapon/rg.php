<?php
//火箭炮类装备详情
header("Content:text/html;charset=utf8");
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db("weapon");
$sql_5="SELECT rg_name FROM rg";
$res_5=mysql_query($sql_5);
$rows_5=array();
while($row_5=mysql_fetch_array($res_5,MYSQL_ASSOC)){
    $rows_5[]=$row_5;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIREARMS_DATA</title>
    <link rel="stylesheet" href="../css/weapon_data.css">
</head>
<body>
    <!--nav导航    -->
    <nav>
        <a href="#" target="myFrameName"><?php echo implode("",$rows_5[0]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[1]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[2]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[3]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[4]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[5]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[6]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[7]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[8]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_5[9]);?></a> 
    </nav>
    <div><iframe id="myFrameId" name="myFrameName"  frameborder="0" src="#" scrolling="auto" ></iframe></div>
</body>
</html>