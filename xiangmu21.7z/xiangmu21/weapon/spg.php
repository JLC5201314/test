<?php
//自行火炮类装备详情
header("Content:text/html;charset=utf8");
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db("weapon");
$sql_4="SELECT spg_name FROM spg";
$res_4=mysql_query($sql_4);
$rows_4=array();
while($row_4=mysql_fetch_array($res_4,MYSQL_ASSOC)){
    $rows_4[]=$row_4;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIREARMS_DATA</title>
    <link rel="stylesheet" href="../css/weapon_data.css">
</head>
<body>
    <!--nav导航    -->
    <nav>
        <a href="#" target="myFrameName"><?php echo implode("",$rows_4[0]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[1]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[2]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[3]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[4]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[5]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[6]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[7]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[8]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_4[9]);?></a> 
    </nav>
    <div><iframe id="myFrameId" name="myFrameName"  frameborder="0" src="#" scrolling="auto" ></iframe></div>
</body>
</html>