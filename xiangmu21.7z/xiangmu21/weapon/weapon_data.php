<!--？？使用php传参，关联文件名-->

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>装备首页</title>
        <script src="../jsp/jquery.js"></script>
        <script src="../jsp/jquery.min.js"></script>
        <link rel="stylesheet" href="../css/layui.css">
    </head>
    <body class="layui-layout-body">
        <div class="layui-layout layui-layout-admin">
          <!--1.头部区域-->
          <div class="layui-header">
            <div class="layui-logo">
                <span>装备详情</span>
                <span style="float: right;margin-right: 40px;"><a href="../logout.php" class="logout">退出</a></span>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-left">
            </ul>
            <ul class="layui-nav layui-layout-right">

          </div>
            <!--2.左侧导航-->
          <div class="layui-side layui-bg-black">
            <div class="layui-side-scroll">
              <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
              <ul class="layui-nav layui-nav-tree"  lay-filter="test">
                <li class="layui-nav-item" data-url="#"  onclick="ShowMenu(level1)"><a>枪械</a></li>
                  <ul id="level1">
                      <li>
                        <span class="layui-sapn" onclick="ShowMenu(level2)"><a>手枪</a></span>
                        <ul id="level2">
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪一'?>" mytitle="手枪一"><a>手枪一</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪二'?>" mytitle="手枪二"><a>手枪二</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪三'?>" mytitle="手枪三"><a>手枪三</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪四'?>" mytitle="手枪四"><a>手枪四</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪五'?>" mytitle="手枪五"><a>手枪五</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪六'?>" mytitle="手枪六"><a>手枪六</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪七'?>" mytitle="手枪七"><a>手枪七</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪八'?>" mytitle="手枪八"><a>手枪八</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪九'?>" mytitle="手枪九"><a>手枪九</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php?name=<?php echo '手枪十'?>" mytitle="手枪十"><a>手枪十</a></li>
                        </ul>
                      </li>
                    <li>
                      <li>
                        <span class="layui-sapn" onclick="ShowMenu(level3)"><a>步枪</a></span>
                        <ul id="level3">
                       <li class="layui-li leftdaohang" data-url="./firearms_2.php?name=<?php echo urlencode('Sasuke 14')?>" mytitle="Sasuke 14"><a>Sasuke 14</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_2.php?name=<?php echo urlencode('Kakashi 49')?>" mytitle="Kakashi 49"><a>Kakashi 49</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_2.php?name=<?php echo urlencode('Sasuke 11')?>" mytitle="Sasuke 11"><a>Sasuke 11</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_2.php?name=<?php echo urlencode('Naruto 34')?>" mytitle="Naruto 34"><a>Naruto 34</a></li>
                        </ul>
                      </li>
                    </li>
                    <li>
                      <li>
                        <span class="layui-sapn" onclick="ShowMenu(level4)"><a>冲锋枪</a></span>
                        <ul id="level4">
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php" mytitle="冲锋枪1"><a>冲锋枪1</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php" mytitle="冲锋枪2"><a>冲锋枪2</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php" mytitle="冲锋枪3"><a>冲锋枪3</a></li>
                        </ul>
                      </li>
                    </li>
                    <li>
                      <li>
                        <span class="layui-sapn" onclick="ShowMenu(level5)"><a>机枪</a></span>
                        <ul id="level5">
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php" mytitle="机枪1"><a>机枪1</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php" mytitle="机枪2"><a>机枪2</a></li>
                          <li class="layui-li leftdaohang" data-url="./firearms_1.php" mytitle="机枪3"><a>机枪3</a></li>
                        </ul>
                      </li>
                    </li>
                  </ul>
                <li class="layui-nav-item leftdaohan" data-url="./ga.php" mytitle="地炮"><a>地炮</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./aag.php" mytitle="高炮"><a>高炮</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./spg.php" mytitle="自行火炮"><a>自行火炮</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./rg.php" mytitle="火箭炮"><a>火箭炮</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./missile.php" mytitle="导弹"><a>导弹</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./radar.php" mytitle="雷达"><a>雷达</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./uav.php" mytitle="无人机"><a>无人机</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./oed.php" mytitle="光电设备"><a>光电设备</a></li>
                <li class="layui-nav-item leftdaohan" data-url="./ccs.php" mytitle="指挥控制系统"><a>指挥控制系统</a></li>
              </ul>
            </div>
          </div>
          <!--3.右侧主体内容区-->
          <div class="layui-body">
             
              <!--tabs标签-->
              <div class="layui-tab layui-tab-card" lay-filter="demo" lay-allowclose="true">
              <ul class="layui-tab-title">
             <!--<li class="layui-this">角色管理</li>-->
              </ul>
              <div class="layui-tab-content" >
              </div>
            </div> 
        
          </div>

          
        </div>
        <script src="../jsp/layui.all.js"></script>
        <script>
            layui.use('element', function(){
              var $ = layui.jquery
              ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
              
              //触发事件
              var active = {
                tabAdd: function(){
                  //新增一个Tab项
                  var htmlurl=$(this).attr('data-url');
                  var mytitle=$(this).attr('mytitle'); 
//                  alert("触发tab增加事件："+mytitle);
                  //先判断是否已经有了tab
                  var arrayObj = new Array();　//创建一个数组  
                      $(".layui-tab-title").find('li').each(function() {
                          var y = $(this).attr("lay-id"); 
                          arrayObj.push(y);
                   });
//                    alert("遍历取到的数组："+arrayObj);
                    var have=$.inArray(mytitle, arrayObj);  //返回 3,
                    if (have>=0) {
                        //tab已有标签
//                        alert("遍历的已有标签："+mytitle);
                      element.tabChange('demo', mytitle); //切换到当前点击的页面
                    } else{
                      //没有相同tab
//                      alert("遍历的没有相同tab："+mytitle);
                      element.tabAdd('demo', {
                        title:mytitle //用于演示
                        ,content: '<iframe style="width: 100%;height:600px" scrolling="auto" frameborder="0" src='+htmlurl+' ></iframe>'
                        ,id: mytitle //实际使用一般是规定好的id，这里以时间戳模拟下
                      })
                      element.tabChange('demo', mytitle); //切换到当前点击的页面
                    }
                }
               
              };
              $(".leftdaohang").click(function(){
                var type="tabAdd";
                var othis = $(this);
                active[type] ? active[type].call(this, othis) : '';
              });
              
            });
        </script>
        <script type="text/javascript">
            function ShowMenu(para){
              if(para.style.display=="block"){
                para.style.display="none";
              }else{
                para.style.display='block';
              }
            }
          </script>
    </body>
</html>