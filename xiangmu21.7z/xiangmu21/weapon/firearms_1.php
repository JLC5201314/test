<?php
header('content-type:text/html;charset=utf-8');
$name=$_GET['name'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql_data="SELECT * FROM 东001手枪 WHERE 名称型号='{$name}'";
//检查是否重复操作
$execute_data=mysql_query($sql_data);
$data=mysql_fetch_array($execute_data,MYSQL_ASSOC);

?>
<!--50式冲锋枪-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>手枪</title>
    <link rel="stylesheet" type="text/css" href="../css/Magnifier.css"/>
	<script src="../jsp/Magnifier.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="../jsp/jquery.js"></script>
    <script type="text/javascript" src="../jsp/jquery.min.js"></script>
  <style type="text/css">
        html{overflow:hidden;}
        .block1 {
            float: left;
            width: 40%;
            height:360px;
            box-sizing: border-box;
        }
        .block2 {
            float: left;
            width: 60%;
            height:360px;
            box-sizing: border-box;
        }
        *{
			margin: 0;
			padding:0;
			
		}
        .button1 {
            padding: 0 10px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    background-color:lightblue;
    font-size: large;
    font-family: Arial, Helvetica, sans-serif;
    color: white;

    border-radius:5px;
    cursor: pointer;
}
  
		
		#small{
            margin-left:20px;
            margin-top:30px;
			position: relative;
			display: inline-block;
			width: 300px;
			height: 200px;
			vertical-align: top;
			overflow: hidden;
 
		}
		#small img{
            margin:15px;
			width: 100%;
			height: 100%;
 
		}
		#big{
			top:20px;
			left:17px;
			width: 480px;
			height: 480px;
			display: inline-block;
			display: none;
			overflow: hidden;
			position: relative;
		}
 
		#move {
			position: absolute;
			width: 50px;
			height: 50px;
			z-index: 1;
			top:0;
			left:0;
			background-color: rgba(50,50,50,0.5);
			background-position: 0 0;
			display: none;
 
		}
		#big img{
			position: absolute;
			left:0px;
			top:0px;
			width: 800px;
			height: 800px;
		}
    </style>

    <script language="javascript">
        function preview(fang) {
            if (fang < 10) {
                bdhtml = window.document.body.innerHTML;//获取当前页的html代码
                sprnstr = "<!--startprint" + fang + "-->";//设置打印开始区域
                eprnstr = "<!--endprint" + fang + "-->";//设置打印结束区域
                prnhtml = bdhtml.substring(bdhtml.indexOf(sprnstr) + 18); //从开始代码向后取html
                prnhtml = prnhtml.substring(0, prnhtml.indexOf(eprnstr));//从结束代码向前取html
                window.document.body.innerHTML = prnhtml;
                window.print();
                window.document.body.innerHTML = bdhtml;
            } else {
                window.print();
            }
        }
    </script>


</head>

<body>

<div class="block1">
     <div id="sell">
		<div id="small">
			<img src="../images/<?php echo $name?>.jpg" alt="">
			<div id="move"></div>
		</div>
		<div id="big">
			<img src="../images/<?php echo $name?>.jpg" alt="">
		</div>
		
</div>
    </div>
    <div class="block2">
        <!--startprint1-->
        <table class="tb" border="0" cellpadding="10" cellspacing="10" style="font-size:x-large;">
            <tr>
                <td>
                    所属类别：手枪
                </td>
                <td>
                    装备名称：<?php echo $data['名称型号'] ?>
                </td>
            </tr>
            <tr>
                <td>
                    现有数量：<?php echo $data['已有数量'] ?>
                </td>
                <td>
                    全宽<?php echo $data['全宽'] ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    口径：<?php echo $data['口径'] ?>枪管的内径，定义是可以塞入时正好贴紧阳膛壁的假想圆筒的直径。一般是测量两个相对的阳膛壁间的距离来断定，也就是膛径。
                </td>
            </tr>
            <tr>
                <td>
                    全长：<?php echo $data['全长'] ?>
                </td>
                <td>
                    全高：<?php echo $data['全高'] ?>
                </td>
            </tr>
            <tr>
                <td>
                    子弹：可装填<?php echo $data['弹药基数'] ?>
                </td>
                <td>
                    存储地点:<?php echo $data['存储地点'] ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    步枪或手枪所使用的弹药，通常包含弹头（bullet）、弹壳（case）、装药（charge）、底火（primer）四部分。
                </td>
            </tr>
            <tr>
                <td>
                    入库时间：<?php echo $data['入库时间'] ?>
                </td>
                <td>
                    出库时间：<?php echo $data['出库时间'] ?>
                </td>
            </tr>
        </table>
        <!--endprint1-->
        <input type='button' name='button_export' title='打印1' class="button1" onclick=preview(1) value='打印'/>
        
    </div>
    </div>

    </div>
    <div style="clear:both;"></div>
    <h1>配件库</h1>
    <script type="text/javascript">
    
  
     //$(".tb td:nth-child(even)").css("background","#bbffaa");
    
    
    </script>
 <script>
	var small = document.getElementById("small");
	var big = document.getElementById("big");
	var divmove = document.getElementById("move");
	small.onmouseenter=function(e){
		e = e||window.event;
		small.onmousemove = function(e){
			e = e||window.event;
			// 小图形的处理
            divmove.style.display = "block";
            big.style.display = "block";
            // 鼠标在盒子中的坐标
			var left = e.clientX+document.body.scrollLeft-small.offsetLeft;
			var top = e.clientY+document.body.scrollTop-small.offsetTop;
			left = left-divmove.offsetWidth/2;
			top = top-divmove.offsetHeight/2;
 
			// move坐标显示在small中
		    left = left<0? 0 : left;
		    top = top<0? 0 : top;
		    left = left>small.offsetWidth-divmove.offsetWidth? small.offsetWidth-divmove.offsetWidth:left;
		    top = top>small.offsetHeight-divmove.offsetHeight? small.offsetHeight-divmove.offsetHeight:top;
 
				divmove.style.display = "block";
				divmove.style.left = left+"px";
				divmove.style.top = top+"px";
				// 大图形处理
				// move 移动的距离/move最大能移动的距离  = bigimg移动的距离/bigimg最大能移动的距离
				bigleft = left*(big.children[0].offsetWidth-big.offsetWidth)/(small.offsetWidth-divmove.offsetWidth);
 
				bigtop = top*(big.children[0].offsetHeight-big.offsetHeight)/(small.offsetHeight-divmove.offsetHeight);
				
				big.children[0].style.left = -bigleft+"px";
				big.children[0].style.top= -bigtop+"px";
		}
		
	}
	small.onmouseleave=function(e){
		e = e||window.event;
		divmove.style.display = "none";
		big.style.display = "none";
		small.onmousemove = function(e){
			
		}
	}
	</script>
</body>

</html>