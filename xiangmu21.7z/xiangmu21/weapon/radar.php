<?php
//雷达类装备详情
header("Content:text/html;charset=utf8");
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db("weapon");
$sql_7="SELECT radar_name FROM radar";
$res_7=mysql_query($sql_7);
$rows_7=array();
while($row_7=mysql_fetch_array($res_7,MYSQL_ASSOC)){
    $rows_7[]=$row_7;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIREARMS_DATA</title>
    <link rel="stylesheet" href="../css/weapon_data.css">
</head>
<body>
    <!--nav导航    -->
    <nav>
        <a href="#" target="myFrameName"><?php echo implode("",$rows_7[0]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[1]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[2]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[3]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[4]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[5]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[6]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[7]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[8]);?></a>  |
        <a href="#" ><?php echo implode("",$rows_7[9]);?></a> 
    </nav>
    <div><iframe id="myFrameId" name="myFrameName"  frameborder="0" src="#" scrolling="auto" ></iframe></div>
</body>
</html>