<?php
//待定……
header("Content:text/html;charset=utf8");
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db("weapon");

$sql="SELECT weapon_type FROM weapon_type";
$res=mysql_query($sql);
$rows=array();
//mysql_fetch_assoc可，自 PHP 5.5.0 起已废弃，并在自 PHP 7.0.0 开始被移除
while($row=mysql_fetch_array($res,MYSQL_ASSOC)){
    $rows[]=$row;
}
//print_r($rows);
//输出原数组
//echo implode("",$rows[0]);

$sql_1="SELECT firearms_name FROM firearms";
$res_1=mysql_query($sql_1);
$rows_1=array();
while($row_1=mysql_fetch_array($res_1,MYSQL_ASSOC)){
    $rows_1[]=$row_1;
}

$sql_2="SELECT ga_name FROM ga";
$res_2=mysql_query($sql_2);
$rows_2=array();
while($row_2=mysql_fetch_array($res_2,MYSQL_ASSOC)){
    $rows_2[]=$row_2;
}

$sql_3="SELECT aag_name FROM aag";
$res_3=mysql_query($sql_3);
$rows_3=array();
while($row_3=mysql_fetch_array($res_3,MYSQL_ASSOC)){
    $rows_3[]=$row_3;
}

$sql_4="SELECT spg_name FROM spg";
$res_4=mysql_query($sql_4);
$rows_4=array();
while($row_4=mysql_fetch_array($res_4,MYSQL_ASSOC)){
    $rows_4[]=$row_4;
}

$sql_5="SELECT rg_name FROM rg";
$res_5=mysql_query($sql_5);
$rows_5=array();
while($row_5=mysql_fetch_array($res_5,MYSQL_ASSOC)){
    $rows_5[]=$row_5;
}

$sql_6="SELECT missile_name FROM missile";
$res_6=mysql_query($sql_6);
$rows_6=array();
while($row_6=mysql_fetch_array($res_6,MYSQL_ASSOC)){
    $rows_6[]=$row_6;
}

$sql_7="SELECT radar_name FROM radar";
$res_7=mysql_query($sql_7);
$rows_7=array();
while($row_7=mysql_fetch_array($res_7,MYSQL_ASSOC)){
    $rows_7[]=$row_7;
}

$sql_8="SELECT uav_name FROM uav";
$res_8=mysql_query($sql_8);
$rows_8=array();
while($row_8=mysql_fetch_array($res_8,MYSQL_ASSOC)){
    $rows_8[]=$row_8;
}

$sql_9="SELECT oed_name FROM oed";
$res_9=mysql_query($sql_9);
$rows_9=array();
while($row_9=mysql_fetch_array($res_9,MYSQL_ASSOC)){
    $rows_9[]=$row_9;
}

$sql_10="SELECT ccs_name FROM ccs";
$res_10=mysql_query($sql_10);
$rows_10=array();
while($row_10=mysql_fetch_array($res_10,MYSQL_ASSOC)){
    $rows_10[]=$row_10;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>装备详情</title>
    <link rel="stylesheet" href="../css/weapon_data.css">
</head>
<body>
    <div class="nav">
        <ul>
            <li><a href="./firearms.php" target="myFrameName"><?php echo implode("",$rows[0]);?></a></li>
            <li><a href="./ga.php" target="myFrameName"><?php echo implode("",$rows[1]);?></a></li>
            <li><a href="./aag.php" target="myFrameName"><?php echo implode("",$rows[2]);?></a></li>
            <li><a href="./spg.php" target="myFrameName"><?php echo implode("",$rows[3]);?></a></li>
            <li><a href="./rg.php" target="myFrameName"><?php echo implode("",$rows[4]);?></a></li>
            <li><a href="./missile.php" target="myFrameName"><?php echo implode("",$rows[5]);?></a></li>
            <li><a href="./radar.php" target="myFrameName"><?php echo implode("",$rows[6]);?></a></li>
            <li><a href="./uav.php" target="myFrameName"><?php echo implode("",$rows[7]);?></a></li>
            <li><a href="./oed.php" target="myFrameName"><?php echo implode("",$rows[8]);?></a></li>
            <li><a href="./ccs.php" target="myFrameName"><?php echo implode("",$rows[9]);?></a></li>
        </ul>
    </div>
    <iframe id="myFrameId" name="myFrameName" scrolling="no" frameborder="0" src="#"></iframe>
</body>
</html>