<?php
$soldier_id=$_GET['soldier_id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
$sq="SELECT * from lv_user where soldier_id='{$soldier_id}'";
$re=mysql_query($sq);
if(mysql_num_rows($re)){
   echo "<script>alert('数据库已存在该用户数据')</script>";
   echo "<script>
   setTimeout(function(){window.location.href='../lvji/userapplication.php';},50);
   </script>  ";
}
else{
   $sql="UPDATE lv_signup set approve='已审核' where soldier_id='{$soldier_id}'";
   $res=mysql_query($sql);
  if($res){
   $sql1="select * from lv_signup where soldier_id='{$soldier_id}'";
   $res1=mysql_query($sql1);
   $row1=mysql_fetch_assoc($res1);
   $sql2="INSERT lv_user(user_id,soldier_id,ID_nums,real_name,user_password,department,permission,class,gender,age,birth,tel,user_address,email) values(null,'{$row1['soldier_id']}','{$row1['ID_nums']}','{$row1['real_name']}','{$row1['user_password']}','{$row1['department']}','{$row1['permission']}','{$row1['class']}','{$row1['gender']}','{$row1['age']}','{$row1['birth']}','{$row1['tel']}','{$row1['user_address']}','{$row1['email']}') ";
      $res1=mysql_query($sql2);
if($res1){
         echo "<script>alert('审核已通过，插入用户表成功')</script>";
         echo "<script>
         setTimeout(function(){window.location.href='../lvji/userapplication.php';},50);
            </script>";
   }

}else{
   echo "<script>alert('审核未通过，数据有误')</script>";
   echo "<script>
   setTimeout(function(){window.location.href='../lvji/lvji.php';},50);
   </script>  ";
}}





?>