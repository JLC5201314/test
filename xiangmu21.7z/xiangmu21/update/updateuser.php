<?php
header("Content-Type: text/html; charset=UTF-8");
$soldier_id=$_GET['soldier_id'];
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
//选择数据库
mysql_select_db('user');

//准备sql语句
$sql="select * from lv_user where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
$rows=mysql_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改用户信息</title>
    <style type="text/css">
        input{
            margin:10px;
            border:1px solid lightblue;
             background-color:transparent;
             border-radius:5px;
             height:25px;
             font-size:medium;
        }
        form{
            margin-top:15%;
        }
        textarea{
        border:1px solid lightblue;
        background-color:transparent;
        resize: none;
        overflow:hidden;
        margin:5px;
        font-size:large;
        border-radius:5px;
}
body{
    background:antiquewhite;
    color:lightskyblue;
}
</style>
</head>
<body>
<form action="./update-user.php" method="POST">
    <table align="center" border="0" cellspacing="0" style="font-size:larger;">
        <tr>
        <td>军人证件号:</td>
        <td style="color:blue;font-size:20px;">&nbsp;&nbsp;&nbsp;<?php echo $soldier_id?></td>
        </tr>
        <tr>
            <td>密码：</td>
            <td><input type="text" name="user_password" value="<?php echo $rows['user_password']?>"/></td>
        </tr>
        <tr>
            <td>所属单位：</td>
            <td><textarea type="text" name="department"  cols="22" rows="2"><?php echo $rows['department']?></textarea></td></td>
        </tr>
        <tr>
            <td>住址：</td>
            <td><textarea type="text" name="user_address" cols="22" rows="2"><?php echo $rows['user_address']?></textarea></td></td>
        </tr>
        <tr>
             <td>邮箱：</td>
            <td><input type="text" name="email" value="<?php echo $rows['email'];?>"/></td>
        </tr>    
        <tr>
            <td colspan="2" align="center">
        <input type="submit" name="修改" value="update" onClick="{if(confirm('你真的要修改吗?')){return true;}return false;}"></td>
        <input type="hidden" value="<?php echo $soldier_id;?>" name="soldier_id">
        </tr>
    </table> 
    </form>
</body>
</html>