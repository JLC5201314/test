<?php
header("Content-Type: text/html; charset=UTF-8");
$user_password=$_POST['user_password'];
$department=$_POST['department'];
$user_address=$_POST['user_address'];
$email=$_POST['email'];
$soldier_id=$_POST['soldier_id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db("user");
$sql="update lv_user set user_password='{$user_password}',department='{$department}',user_address='{$user_address}',email='{$email}' where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
if($res){
    echo "<script>alert('修改信息成功')</script>";
    //echo "<script>setTimeout(function(){var opened=window.open('about:blank','_self');
      //  opened.opener=null;
       // opened.close();},50);</script>";
    echo "<script>setTimeout(function(){window.location.href='../lvji/admindatatb.php'},50);</script>";
    
}
else{
    echo "<script>alert('修改信息失败')</script>";
    echo "<script>setTimeout(function(){window.location.href='../lvji/admindatatb.php'},50);</script>";
}

?>