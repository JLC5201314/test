<?php
$soldier_id=$_GET['soldier_id'];
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
//选择数据库
mysql_select_db('user');
$sql="UPDATE lv_signup set approve='已拒绝' where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
if($res){
  $sql1="SELECT * from lv_user where soldier_id='{$soldier_id}'";
  $res1=mysql_query($sql1);
  if(mysql_num_rows($res1)){
    $sql2="DELETE from lv_user where soldier_id='{$soldier_id}'";
    $res2=mysql_query($sql2);
    if($res2){echo "<script>alert('审核已拒绝')</script>alert('')";
    echo "<script>
            setTimeout(function(){window.location.href='../lvji/userapplication.php';},50);
            </script>";}
    
  }
  else{
    echo "<script>alert('审核拒绝')</script>alert('')";
    echo "<script>
            setTimeout(function(){window.location.href='../lvji/userapplication.php';},50);
            </script>";
  }
  }
        
?>