<?php 
header("Content-Type: text/html; charset=UTF-8");
header("Cache-control: private, must-revalidate");
$soldier_id=$_POST['soldier_id'];
$department=$_POST['department'];
$real_name=$_POST['real_name'];
$ID_num=$_POST['ID_num'];
$gender=$_POST['gender'];
$user_address=$_POST['address'];
$email=$_POST['email'];
$birth=$_POST['birth'];
$age=date('Y')-substr($ID_num,6,4);
$tel=$_POST['tel'];
$user_password=$_POST['password'];
$passcode=$_POST['passcode'];
$permission=$_POST['permission'];
$class=$_POST['class'];
/*if($soldier_id==null&&$department==null&&$real_name==null&&$ID_num==null&&$gender==null&&$address==null&&$email==null&&$birth==null&&$age==null&&$tel==null&&$password==null&&$p_confirm==null&&$passcode==null&&$permission==null){
	echo '信息填写不完整，请重新输入';
	echo "<script>
	setTimeout(function(){window.location.href='./signup.html';},1500);
	</script>";
};*/
// 调用方法
function validation_filter_id_card($id_card){
    if(strlen($id_card)==18){
        return idcard_checksum18($id_card);
    }elseif((strlen($id_card)==15)){
        $id_card=idcard_15to18($id_card);
        return idcard_checksum18($id_card);
    }else{
        return false;
    }
}
// 计算身份证校验码，根据国家标准GB 11643-1999
function idcard_verify_number($idcard_base){
    if(strlen($idcard_base)!=17){
        return false;
    }
    //加权因子
    $factor=array(7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2);
    //校验码对应值
    $verify_number_list=array('1','0','X','9','8','7','6','5','4','3','2');
    $checksum=0;
    for($i=0;$i<strlen($idcard_base);$i++){
        $checksum += substr($idcard_base,$i,1) * $factor[$i];
    }
    $mod=$checksum % 11;
    $verify_number=$verify_number_list[$mod];
    return $verify_number;
}
// 将15位身份证升级到18位
function idcard_15to18($idcard){
    if(strlen($idcard)!=15){
        return false;
    }else{
        // 如果身份证顺序码是996 997 998 999，这些是为百岁以上老人的特殊编码
        if(array_search(substr($idcard,12,3),array('996','997','998','999')) !== false){
            $idcard=substr($idcard,0,6).'18'.substr($idcard,6,9);
        }else{
            $idcard=substr($idcard,0,6).'19'.substr($idcard,6,9);
        }
    }
    $idcard=$idcard.idcard_verify_number($idcard);
    return $idcard;
}
// 18位身份证校验码有效性检查
function idcard_checksum18($idcard){
    if(strlen($idcard)!=18){
        return false;
    }
    $idcard_base=substr($idcard,0,17);
    if(idcard_verify_number($idcard_base)!=strtoupper(substr($idcard,17,1))){
        return false;
    }else{
        return true;
    }
}
include_once "./connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
if(validation_filter_id_card($ID_num)){ 
	if($age==(date("Y")-substr($ID_num,6,4))){
        session_start();//启动会话
        if($passcode==$_SESSION['authcode']){
                switch($class){
                    case "旅级":
                        $sql="select * from lv_signup where soldier_id='{$soldier_id}'";
                        $res=mysql_query($sql);
                        $num=mysql_num_rows($res);
                        if($num==0){
                            $sql1="INSERT lv_signup(user_id,soldier_id,ID_nums,real_name,user_password,department,permission,class,gender,age,birth,tel,user_address,email) values(null,'{$soldier_id}','{$ID_num}','{$real_name}','{$user_password}','{$department}','{$permission}','{$class}','{$gender}','{$age}','{$birth}','{$tel}','{$user_address}','{$email}') ";
                            $res1=mysql_query($sql1);
                            if($res1){
                                echo "<script>alert('已注册，请等待审核')</script>";
                                echo "<script>
                                setTimeout(function(){window.location.href='./login.html';},50);
                                  </script>";
                            }
                        }
                        else{
                            echo "<script>alert('此军人证件号已被注册，请重新输入')</script>";
                            echo "<script>
                                setTimeout(function(){window.location.href='./signup.html';},50);
                                  </script>";
                        }
                    break;
                    case "军级":
                        $sql="select * from jun_signup where soldier_id='{$soldier_id}'";
                        $res=mysql_query($sql);
                        $num=mysql_num_rows($res);
                        if($num==0){
                            $sql1="INSERT jun_signup(user_id,soldier_id,ID_nums,real_name,user_password,department,permission,class,gender,age,birth,tel,user_address,email) values(null,'{$soldier_id}','{$ID_num}','{$real_name}','{$user_password}','{$department}','{$permission}','{$class}','{$gender}','{$age}','{$birth}','{$tel}','{$user_address}','{$email}') ";
                            $res1=mysql_query($sql1);
                            if($res1){
                                echo "<script>alert('已注册，请等待审核')</script>";
                                echo "<script>
                                setTimeout(function(){window.location.href='./login.html';},50);
                                  </script>";
                            }
                        }
                        else{
                            echo "<script>alert('此军人证件号已被注册，请重新输入')</script>";
                            echo "<script>
                            setTimeout(function(){window.location.href='./signup.html';},50);
                              </script>";
                        }
                    break;
                    case "战区级":
                        $sql="select * from zhanqu_signup where soldier_id='{$soldier_id}'";
                        $res=mysql_query($sql);
                        $num=mysql_num_rows($res);
                        if($num==0){
                            $sql1="INSERT zhanqu_signup(user_id,soldier_id,ID_nums,real_name,user_password,department,permission,class,gender,age,birth,tel,user_address,email) values(null,'{$soldier_id}','{$ID_num}','{$real_name}','{$user_password}','{$department}','{$permission}','{$class}','{$gender}','{$age}','{$birth}','{$tel}','{$user_address}','{$email}') ";
                            $res1=mysql_query($sql1);
                            if($res1){
                                echo "<script>alert('已注册，请等待审核')</script>";
                                echo "<script>
                                setTimeout(function(){window.location.href='./signup.html';},50);
                                </script>";
                            }
                        }
                        else{
                            echo "<script>alert('此军人证件号已被注册，请重新输入')</script>";
                            echo "<script>
                            setTimeout(function(){window.location.href='./signup.html';},50);
                            </script>";
                        }
                    break;
                }
        }
        else{
            echo "<script>alert('验证码错误，请重新输入')</script>";
            echo "<script>
            setTimeout(function(){window.location.href='./signup.html';},50);
            </script>";
        }
    }
    else{
        echo "<script>alert('输入的年龄有误')</script>";
        echo "<script>
        setTimeout(function(){window.location.href='./signup.html';},50);
        </script>";
        
    }
  
}
else{
    echo "<script>alert('请输入有效的身份证号')</script>";
    echo "<script>
        setTimeout(function(){window.location.href='./signup.html';},50);
        </script>";
}

/*
if(!isset($_POST['submit'])){
		exit("错误执行");
	}//判断是否有submit操作
$name=$_POST['name'];//post获取表单里的name
 $password=$_POST['password'];//post获取表单里的password
$class=$_POST['class'];//post获取表单里的class

session_start();//启动会话
$pass$ID_num=$_POST["pass$ID_num"];
if( $pass$ID_num == $_SESSION['auth$ID_num']){
			//链接数据库
			$link=@mysql_connect('localhost','root','');
			mysql_select_db('admin');
			mysql_query('set names utf8');
			$q="insert into user values (null,'{$name}','{$password}','{$class}')";//向数据库插入表单传来的值的sql
			$reslut=mysql_query($q);//执行sql

			if ($reslut){
					echo '注册成功';
					header("Location:registersucc.php");
			}else
			{
					echo '注册失败';
			 } 
}else
{
		echo '输入的验证码有误';
	    echo "<script>
	setTimeout(function(){window.location.href='./signup.html';},1500);
	</script>";
}*/


?>
