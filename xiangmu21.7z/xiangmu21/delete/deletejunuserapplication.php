<?php
$soldier_id=$_GET['soldier_id'];
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
$sql="delete from jun_signup where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
if($res){
    echo "<center>审核不通过，已删除</center>";
    echo "<script>
    setTimeout(function(){window.location.href='../junji/junuserapplication.php';},1000);
      </script>";
}
?>
