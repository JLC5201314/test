<?php
$soldier_id=$_GET['soldier_id'];
//链接数据库
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('user');
$sql="delete from lv_signup where soldier_id='{$soldier_id}'";
$res=mysql_query($sql);
if($res){
    echo "<script>alert('删除成功')</script>";
    echo "<script>
    setTimeout(function(){window.location.href='../lvji/userapplication.php';},50);
      </script>";
}



?>