<?php
function connect_mysql(){
   @mysql_connect('localhost','root',''); 
   mysql_query('set names utf8');
}



?>