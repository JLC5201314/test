<?php
header('content-type:text/html;charset=utf-8');
  include_once "../fn.php";
  // 作用, 判断用户是否登录, 如果未登录, 拦截到登录页
  is_login();
$tbname=$_GET['tbname'];
$permission=$_SESSION['permission'];
switch ($tbname) {
    case '东001手枪':
            if($permission=='管理员'){
                header("refresh:0;url=./showshouqiang.php");
            }else{
                header("refresh:0;url=./showusershouqiang.php");
            }
      ;
        break;
    case '东001步枪':
        header("refresh:0;url=./showbuqiang.php");
        break;
    default:
        # code...
        break;
}
?>