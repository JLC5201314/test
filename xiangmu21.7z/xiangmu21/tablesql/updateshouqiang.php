<?php
header('content-type:text/html;charset=utf-8');
$id=$_GET['id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="select * from 东001手枪 where 名称型号='{$id}'";
$res=mysql_query($sql);
$row=mysql_fetch_assoc($res);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改数据</title>
    <style type="text/css">
        input{
            margin:10px;
            border:1px solid lightblue;
             background-color:transparent;
             border-radius:5px;
             height:25px
        }

</style>
</head>
<body>
<form action="./update-shouqiang.php" method="POST">
    <table align="center" border="0" cellspacing="0" style="font-size:large;">
        <tr>
            <td>口径：</td>
            <td><input type="text" name="口径" value="<?php echo $row['口径'];?>"/></td>
        </tr>
        <tr>
            <td>全长：</td>
            <td><input type="text" name="全长" value="<?php echo $row['全长'];?>"/></td>
        </tr>
        <tr>
             <td>全高：</td>
            <td><input type="text" name="全高" value="<?php echo $row['全高'];?>"/></td>
        </tr>
        <tr>
            <td>全宽：</td>
            <td><input type="text" name="全宽" value="<?php echo $row['全宽'];?>"/></td>
        </tr>
        <tr>
             <td>枪重（带空弹匣）：</td>
            <td><input type="text" name="枪重（带空弹匣）" value="<?php echo $row['枪重（带空弹匣）'];?>"/></td>
        </tr>
        <tr>
            <td>弹药基数：</td>
            <td><input type="text" name="弹药基数" value="<?php echo $row['弹药基数'];?>"/></td>
        </tr>   
        <tr>
            <td>瞄准基线长：</td>
            <td><input type="text" name="瞄准基线长" value="<?php echo $row['瞄准基线长'];?>"/></td>
        </tr>    
        <tr>
            <td>射程：</td>
            <td> <input type="text" name="射程" value="<?php echo $row['射程'];?>"/></td>
        </tr>   
        <tr>
            <td> 初速：</td>
            <td><input type="text" name="初速" value="<?php echo $row['初速'];?>"/></td>
        </tr>    
        <tr>
            <td>已有数量： </td>
            <td>  <input type="text" name="已有数量" value="<?php echo $row['已有数量'];?>"/></td>
        </tr>    
        <tr>
            <td>报废数量 ：</td>
            <td> <input type="text" name="报废数量" value="<?php echo $row['报废数量'];?>"/></td>
        </tr>    
        <tr>
            <td>入库时间 ：</td>
            <td> <input type="text" name="入库时间" value="<?php echo $row['入库时间'];?>"/></td>
        </tr>    
        <tr>
            <td>入库数量 ：</td>
            <td>   <input type="text" name="入库数量" value="<?php echo $row['入库数量'];?>"/></td>
        </tr>    
        <tr>
            <td>出库时间 ：</td>
            <td> <input type="text" name="出库时间" value="<?php echo $row['出库时间'];?>"/></td>
        </tr>   
        <tr>
            <td>出库数量 ：</td>
            <td><input type="text" name="出库数量" value="<?php echo $row['出库数量'];?>"/></td>
        </tr>    
        <tr>
            <td>存储地点：</td>
            <td> <input type="text" name="存储地点" value="<?php echo $row['存储地点'];?>"/></td>
        </tr>    
        <tr>
            <td colspan="2" align="center"><input type="hidden" value="<?php echo $tbname;?>" name="tbname">
        <input type="submit" name="修改" value="update"></td>
        <input type="hidden" value="<?php echo $id;?>" name="id">
        </tr>
    </table> 
    </form>
</body>
</html>