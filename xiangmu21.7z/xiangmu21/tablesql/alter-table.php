<?php
header('content-type:text/html;charset=utf-8');
$newtbname=$_POST['newtbname'];
$oldtbname=$_POST['oldtbname'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="alter table {$oldtbname} rename to {$newtbname}";
//发送sql语句
$res=mysql_query($sql);
//判断是否成功
if($res){
    echo '修改成功';
    echo "<script>
    setTimeout(function(){window.location.href='./showtable.php';},3000);
    </script>";
}else{
	echo '修改失败';
}
?>
