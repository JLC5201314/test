<?php
header('content-type:text/html;charset=utf-8');
$tbname=$_GET['tbname'];
$tbname=$_GET['tbname'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="drop table {$tbname}";
$res=mysql_query($sql);
if($res){
    echo '删除成功';
    echo "<script>
        setTimeout(function(){
            window.location.href='./showtable.php';
        },3000)
    </script>";
}else{
    echo '删除失败';
}
?>