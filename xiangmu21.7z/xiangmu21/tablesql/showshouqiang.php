<?php
header('content-type:text/html;charset=utf-8');
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="select * from 东001手枪 order by ordnanceId";
$res=mysql_query($sql);
$rows=array();
	 while($row = mysql_fetch_assoc($res)){
	  $rows[]=$row;
	}
foreach($rows as $v){
    $x[]=$v['名称型号'];
    $y[]=$v['已有数量'];
    $j[]=$v['报废数量'];
    $m[]=$v['报废数量']/$v['已有数量'];
    $n[]=1-$v['报废数量']/$v['已有数量'];
}
$json_x=json_encode($x);
$json_y=json_encode($y);
$json_z=json_encode($m);
$json_j=json_encode($j);
$json_m0=json_encode(number_format($m[0],4));
$json_n0=json_encode(number_format($n[0],4));
$json_m1=json_encode(number_format($m[1],4));
$json_n1=json_encode(number_format($n[1],4));
$json_m2=json_encode(number_format($m[2],4));
$json_n2=json_encode(number_format($n[2],4));
$json_m3=json_encode(number_format($m[3],4));
$json_n3=json_encode(number_format($n[3],4));
$json_m4=json_encode(number_format($m[4],4));
$json_n4=json_encode(number_format($n[4],4));
$json_m5=json_encode(number_format($m[5],4));
$json_n5=json_encode(number_format($n[5],4));
$json_m6=json_encode(number_format($m[6],4));
$json_n6=json_encode(number_format($n[6],4));
$json_m7=json_encode(number_format($m[7],4));
$json_n7=json_encode(number_format($n[7],4));
$json_m8=json_encode(number_format($m[8],4));
$json_n8=json_encode(number_format($n[8],4));
$json_m9=json_encode(number_format($m[9],4));
$json_n9=json_encode(number_format($n[9],4));
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>手枪详情</title>
  <script src="../jsp/jquery.js"></script>
  <script src="../jsp/jquery.min.js"></script>
  <script src="../jsp/echarts.min.js"></script>
  <style type="text/css">
    .div1 {
      text-align: center;
      margin-top: 1%;
      margin-bottom: 2%;
    }
    .div2{
      text-align: center;
      margin-top: 5px;
      margin-bottom: 5px;
    }

    ul {
      margin: 0px;
      padding: 0px;
    }

    ul li {
      margin: 0px;
      list-style: none;
      border: 1px solid pink;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background-color: lightblue;
    }

    ul li a {
      text-decoration: none;
      background: lightblue;
    }

    ul li a:hover {
      background-color: pink;
      display: block;

    }

    #left {
      float: left;
      width: 80px;
      border: 1px solid pink;
      box-sizing: border-box;
    }
    .clear{
      clear:both;
    }
    #content {
      float: left;
      background-color:lightblue;
      width: 520px;
      height: 322px;
      box-sizing: border-box;
    }
    #main{
      margin-top:30px;
      float:left;
      margin-left:2%;
    }
    #content>div{
      display:none;
    }
   .wrapper {
      margin-top: 30px !important;
      margin-left: 15px !important;
      margin-right: 2% !important;
      margin: 0px;
      width: 680px;
      float:right;
      height: 323px;
      background-color:lightblue;
    
    }
    td{
      text-align:center !important;
    }
  </style>
  <script type="text/javascript">
    $(function () {
      $("#left li").mouseover(function () {
        var index = $(this).index();
        console.log(index);
        $("#content>div").eq(index).show();
        $("#content>div").eq(index).siblings().hide();
      })
    })

  </script>
</head>

<body>
  <div class="div1">
  <div class="div2">
    <a href="./addshouqiang.php?">添加数据</a>
  


  <table border="1" align="center" cellspacing="0" cellpadding="2" style="margin-left:1%;margin-right:1%;font-size:medium" >
    <tr>
      <th>名称型号</th>
      <th>口径</th>
      <th>全长</th>
      <th>全高</th>
      <th>全宽</th>
      <th>枪重（带空弹匣）</th>
      <th>弹药基数</th>
      <th>瞄准基线长</th>
      <th>射程</th>
      <th>初速</th>
      <th>已有数量</th>
      <th>报废数量</th>
      <th>损耗率</th>
      <th>入库时间</th>
      <th>入库数量</th>
      <th>出库时间</th>
      <th>出库数量</th>
      <th>存储地点</th>
      <th>操作</th>
     

    </tr>
    <?php foreach($rows as $v):?>
    <tr>
      <td><?php echo $v['名称型号']?></td>
      <td><?php echo $v['口径']?></td>
      <td><?php echo $v['全长']?></td>
      <td><?php echo $v['全高']?></td>
      <td><?php echo $v['全宽']?></td>
      <td><?php echo $v['枪重（带空弹匣）']?></td>
      <td><?php echo $v['弹药基数']?></td>
      <td><?php echo $v['瞄准基线长']?></td>
      <td><?php echo $v['射程']?></td>
      <td><?php echo $v['初速']?></td>
      <td><?php echo $v['已有数量']?></td>
      <td><?php echo $v['报废数量']?></td>
      <td style="color:<?php echo $v['报废数量']/$v['已有数量'] >= 0.05? 'red': 'green';?>"><?php echo sprintf("%01.2f", $v['报废数量']/$v['已有数量']*100).'%'?></td>
      <td><?php echo $v['入库时间']?></td>
      <td><?php echo $v['入库数量']?></td>
      <td><?php echo $v['出库时间']?></td>
      <td><?php echo $v['出库数量']?></td>
      <td><?php echo $v['存储地点']?></td>
      <td><a href="./updateshouqiang.php?id=<?php echo $v['名称型号']?>">修改</a> <a
          href="./deleteshouqiang.php?id=<?php echo $v['名称型号']?>"
          onClick="{if(confirm('你真的要删除吗?')){return true;}return false;}">删除</a>
      </td>
     

    </tr>
    <?php endforeach;?>

  </table>
  </div>
  <div style="margin-top:3%;">
    <div id="main" style="width: 700px;height:323px;"></div>
    <div class="wrapper">
    <ul id="left">
      <?php foreach($x as $v):?>
      <li><?php echo $v;?></li>
      <?php endforeach;?>
    </ul>
    <div id="content">
      <div><div id="main1" style="width: 580px;height:300px;"></div></div>
      <div><div id="main2" style="width: 580px;height:300px;"></div></div>
      <div><div id="main3" style="width: 580px;height:300px;"></div></div>
      <div><div id="main4" style="width: 580px;height:300px;"></div></div>
      <div><div id="main5" style="width: 580px;height:300px;"></div></div>
      <div><div id="main6" style="width: 580px;height:300px;"></div></div>
      <div><div id="main7" style="width: 580px;height:300px;"></div></div>
      <div><div id="main8" style="width: 580px;height:300px;"></div></div>
      <div><div id="main9" style="width: 580px;height:300px;"></div></div>
      <div><div id="main10" style="width: 580px;height:300px;"></div></div> 
    </div> 
     <div class="clear"></div>
  </div>

  

  <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var y =<?php echo $json_y?>;

    // 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('main'));

    // 指定图表的配置项和数据
    var option = {
      title: {
        text: '东001手枪'
      },
      tooltip: {
        //  formatter: "{c}支"  //设置鼠标划上提示文字
      },
      grid: {
        left: '1%',
        right: '0',
        bottom: '2%',
  
        containLabel: true
      },
      /*  grid: {  //设置图标距离
        top: "50",
        left: "50",
        right: "0",
        bottom: "50"
      },*/
      legend: {
        data: ['数量']
      },
      xAxis: {
        data: x,
        type: "category",
        axisLabel: {
          interval:0,

          rotate:30,
          textStyle: {
            //文字样式
            color: "#62799C",
            fontSize: "11",
            fontWeight: "bloder"
          }
        },
        max: x.length,
        axisTick: {
          //x轴不显示刻度线，
          show: false,
        },
        axisLine: {
          //隐藏x轴线
          show: true,
          symbol: ['none', 'arrow'],
        },
      },
      yAxis: {
        type: "value",
        name: '数量/支',
        show: true,
        axisLabel: {
          textStyle: {
            //文字样式
            color: "#62799C",
            fontSize: "14"
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            // 使用深浅的间隔色
          }
        },
        axisTick: {
          //y轴不显示刻度线，
          show: false
        },
        axisLine: {
          //隐藏y轴线
          show: true,
          symbol: ['none', 'arrow'],
          symbolOffset: 12,
        }
      },
      series: [{
        name: '数量',
        type: "bar",
        data: y,
        itemStyle: {
          normal: {
            color: "rgba(160,216,254,1)",//柱状图的背景颜色
            label: {
              show: true, //开启显示
              position: 'top', //在上方显示
              textStyle: { //数值样式
                color: 'black',
                fontSize: 16
              }
            }
          }
        },
        barWidth: 25,  //柱状图宽度
        barCategorGap: '80%',
        // barGap: '20%'  //设置同一类中两个柱状图的距离
      }]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
  </script>
  <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m0?>;
    var n =<?php echo $json_n0?>;
    var myChart = echarts.init(document.getElementById('main1'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 16    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[0],
            fill: 'skyblue',
            fontSize: 20,
            fontWeight: 'blod'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6','red', '#11abff',  '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 18    //文字大小
        }
      },
      series: [
        {
          name: x[0],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
   <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m1?>;
    var n =<?php echo $json_n1?>;
    var myChart = echarts.init(document.getElementById('main2'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[1],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[1],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
  <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m2?>;
    var n =<?php echo $json_n2?>;
    var myChart = echarts.init(document.getElementById('main3'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[2],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[2],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
  <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m3?>;
    var n =<?php echo $json_n3?>;
    var myChart = echarts.init(document.getElementById('main4'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[3],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[3],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
  <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m4?>;
    var n =<?php echo $json_n4?>;
    var myChart = echarts.init(document.getElementById('main5'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[4],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[4],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script> <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m5?>;
    var n =<?php echo $json_n5?>;
    var myChart = echarts.init(document.getElementById('main6'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[5],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[5],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
   <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m6?>;
    var n =<?php echo $json_n6?>;
    var myChart = echarts.init(document.getElementById('main7'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[6],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[6],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
   <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m7?>;
    var n =<?php echo $json_n7?>;
    var myChart = echarts.init(document.getElementById('main8'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[7],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[7],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
   <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m8?>;
    var n =<?php echo $json_n8?>;
    var myChart = echarts.init(document.getElementById('main9'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[8],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[8],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
   <script type="text/javascript">
    var x =<?php echo $json_x?>;
    var m =<?php echo $json_m9?>;
    var n =<?php echo $json_n9?>;
    var myChart = echarts.init(document.getElementById('main10'));
    option = {
      title: {//标题组件
        textStyle: {
          color: "#333333",
          fontSize: 14,
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)",
        textStyle: {    //图例文字的样式
          color: '#fff',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      graphic: [
        {
          type: 'text',
          top: '35%',
          left: 'center',
          style: {
            text: '装备名称',
            fill: '#333333',
            fontSize: 16,
            fontWeight: 'normal'
          }
        }, {
          type: 'text',
          top: '43%',
          left: 'center',
          style: {
            text: x[9],
            fill: 'lightblue',
            fontSize: 20,
            fontWeight: 'normal'
          }
        },
      ],
      //圆环的颜色
      color: ['#48cda6', 'red', '#11abff', '#ffdf6f', '#968ade'],
      // 图例
      legend: {
        // 图例选择的模式，控制是否可以通过点击图例改变系列的显示状态。默认开启图例选择，可以设成 false 关闭。
        selectedMode: true,
        orient: 'vertical',
        x: 'right',   //图例显示在右边
        y: 'bottom',   //图例在垂直方向上面显示居中
        bottom: 0,
        itemWidth: 10,  //图例标记的图形宽度
        itemHeight: 10, //图例标记的图形高度
        data: ['完好率', '损耗率'],
        textStyle: {    //图例文字的样式
          color: '#A6A8B6',  //文字颜色
          fontSize: 14    //文字大小
        }
      },
      series: [
        {
          name: x[9],//代表a的值，系列名称
          type: 'pie',
          center: ['55%', '45%'], //饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
          radius: ['0%', '60%'],//饼图的半径，数组的第一项是内半径，第二项是外半径。[ default: [0, '75%'] ]
          avoidLabelOverlap: false,
          /*  animation: false, */  //是否禁用动画效果
          label: {
            normal: {
              show: true,//是否显示标签
              //  标签的位置。'outside'饼图扇区外侧，通过视觉引导线连到相应的扇区。'inside','inner' 同 'inside',饼图扇区内部。'center'在饼图中心位置。
              position: 'left',
              //显示的标签的内容
              //a（系列名称），b（数据项名称），c（数值）, d（百分比）
              formatter: "{a},{b}:{d}%",   //![在这里插入图片描述](https://img-blog.csdn.net/2018101313580390?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5MzI3NDE4/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

            },
            emphasis: {
              //鼠标放在圆环上显示的标签样式
              show: true,
              textStyle: {
                fontSize: '14',
                fontWeight: 'bold'
              }
            }
          },
          labelLine: {
            normal: {
              show: true,//是否显示引导线
              length: 10,  //百分比引导线
              length2: 20    //视觉引导项第二段的长度。
            }
          },
          itemStyle: {
            normal: {
              borderColor: "#FFFFFF",
              borderWidth: 1,
              label: {
                show: true,
                formatter: '{d}%'
              },
            }
          },
          // 系列中的数据内容数组。
          data: [
            { value: n, name: '完好率' },
            { value: m, name: '损耗率' },
          ]
        }
      ]
    };
    myChart.setOption(option);


  </script>
  <script type="text/javascript">
      
    $(function () {
      $("table th").css("background", "lightgray")
      $("table tr:nth-child(odd)").css("background", "lightblue");
      
      
     // $("table td:nth-child(13)").css("color", "green")
    })
  </script>
  <script type="text/javascript">
    var x=<?php echo $json_x?>;
    var y=<?php echo $json_y?>;
    var j=<?php echo $json_j?>;
    var arrs=[];
    for(var i = 0;i < y.length;i++)
    {
      
     arrs[i]=$("table td:nth-child(13)").eq(i).text()
       
     //   alert('装备耗损过大，请及时补充');
      
     // console.log(Math.round(j[i]/y[i]*10000)/100.0 + "%");
     // console.log((m[i].toFixed(4))*100+"%");
    }
    var s="";
    for(var i = 0;i < y.length;i++)
    {
      
     if((arrs[i].replace("%","")/100)>0.05){
      s=s+" "+ x[i];
     }
       
     //   alert('装备耗损过大，请及时补充');
      
     // console.log(Math.round(j[i]/y[i]*10000)/100.0 + "%");
     // console.log((m[i].toFixed(4))*100+"%");
    }
    alert(s +' 损耗率过高，请及时处理');
    
  </script>
</body>

</html>