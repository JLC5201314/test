<?php
header('content-type:text/html;charset=utf-8');
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
//准备sql语句
$sql="show tables";
$res=mysql_query($sql);
$rows=array();
while($row = mysql_fetch_assoc($res)){
	//rows就是一个二维数组
	$rows[]=$row;
}
$nums=mysql_num_rows($res);

?>


<!DOCTYPE html>
<html>
	     <head>
			<meta charset = "UTF-8" />  <!-----网页的显示编码--->
			<title>装备表</title> <!----网页的标题---->
			<script src="../jsp/jquery.js"></script>
        <script src="../jsp/jquery.min.js"></script>
			<style type="text/css">
				input{
					margin:10px;
				}
				.container{
					width:90%;
					margin:0 auto;
					margin-top:25px;
				}
				form{
					margin-left:500px;
				}
		</style>
	     </head>
		 <body>
		 <div class="container"><table border="1"  cellspacing="0" align="center">
				<tr>
					<th>表名</th>
					<th>操作</th>
				</tr>
				<?php foreach($rows as $v):?>
				<tr>
					<td><?php echo $v['Tables_in_ordnance'];?></td>
					<td colspan="2">
					    <a href="./select.php?tbname=<?php echo $v['Tables_in_ordnance'];?>">查看</a>
						<a href="./altertable.php?tbname=<?php echo $v['Tables_in_ordnance'];?>">修改</a>
						<a href="./droptable.php?tbname=<?php echo $v['Tables_in_ordnance'];?>" onClick="{if(confirm('你真的要删除吗?')){return true;}return false;}" >删除</a>
					</td>
				</tr>
				<?php endforeach;?>
            </table>
					
    <form action="./createtable.php" method="POST">
        请输入表名: <input type="text" name="tbname"/>
		<input type="submit" name="提交" value="提交"/>
    </form>
			
</div>
<script type="text/javascript">
   $(function(){
	   $("table th").css("background","lightgray")
	   $("table tr:nth-child(odd)").css("background","lightblue")
   })

</script>
</body>
</html>
