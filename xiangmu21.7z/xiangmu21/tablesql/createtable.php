<?php
header("Content:text/html;charset=utf8");
$tbname=$_POST['tbname'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="CREATE table {$tbname}(
    fa_id int(8) zerofill not null auto_increment,
    名称型号 varchar(20) not null,
    口径 varchar(10) not null,
    全长 varchar(10) not null,  
    全高 varchar(10) not null,
    全宽 varchar(10) not null,
    枪重（带空弹匣） varchar(10) not null,
    弹药基数 varchar(10) not null,
    瞄准基线长 varchar(10) not null,
    射程 varchar(10) not null,
    初速 varchar(10) not null,
    已有数量 int not null,
    报废数量 int not null,
    入库时间 date not null,
    入库数量 int not null,
    出库时间 date not null,
    出库数量 int not null,
    存储地点 text not null,
    primary key(fa_id,名称型号)
  )charset=utf8;";
  $res=mysql_query($sql);
  if($res){
      echo '创建成功';
      echo "<script>
      setTimeout(function(){window.location.href='./showtable.php';},3000);
      </script>";
  }else{
      echo "<script>
    setTimeout(function(){window.location.href='./showtable.php';},3000);
    </script>";
  }



?>