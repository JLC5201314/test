<?php
header('content-type:text/html;charset=utf-8');
$tbname=$_GET['tbname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="./alter-table.php" method="POST">
        请输入新的表名: <input type="text" value="<?php echo $tbname;?>" name="newtbname"/>
        <input type="submit" value="submit" name="提交">
        <input type="hidden" value="<?php echo $tbname;?>" name="oldtbname"/>
    </form>
</body>
</html>