<?php
header('content-type:text/html;charset=utf-8');
$tbname=$_GET['tbname'];
$id=$_GET['id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="DELETE from 东001手枪 where 名称型号='{$id}'";
$res=mysql_query($sql);
if($res){
    echo "<script>alert('删除成功')</script>";
    echo "<script>
    setTimeout(function(){window.location.href='./showtable.php';},50);
    </script>";
}
?>
