<?php
$名称型号=$_POST['名称型号'];
$口径=$_POST['口径'];
$全长=$_POST['全长'];
$全高=$_POST['全高'];
$全宽=$_POST['全宽'];
$枪重（带空弹匣）=$_POST['枪重（带空弹匣）'];
$弹药基数=$_POST['弹药基数'];
$瞄准基线长=$_POST['瞄准基线长'];
$射程=$_POST['射程'];
$初速=$_POST['初速'];
$已有数量=$_POST['已有数量'];
$报废数量=$_POST['报废数量'];
$入库时间=$_POST['入库时间'];
$入库数量=$_POST['入库数量'];
$出库时间=$_POST['出库时间'];
$出库数量=$_POST['出库数量'];
$存储地点=$_POST['存储地点'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('ordnance');
$sql="INSERT 东001手枪 value(null,'{$名称型号}','{$口径}','{$全长}','{$全高}','{$全宽}','{$枪重（带空弹匣）}','{$弹药基数}','{$瞄准基线长}','{$射程}','{$初速}','{$已有数量}','{$报废数量}','{$入库时间}','{$入库数量}','{$出库时间}','{$出库数量}','{$存储地点}')";
$res=mysql_query($sql);
if($res){
    echo "<script>alert('插入成功')</script>";
    echo "<script>
        setTimeout(function(){window.location.href='./showtable.php';},50);
    </script>";
}else{
    echo '插入失败';
}

?>