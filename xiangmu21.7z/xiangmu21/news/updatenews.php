<?php 
$id=$_GET['id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');
$sql="select * from news where id='{$id}'";
$res=mysql_query($sql);
$rows=mysql_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改公告</title>
    <style type="text/css"> 
        input{
            height: 25px;
            border:1px solid #d2d2d2;
            background-color:transparent;
            border-radius:5px;
        }
        textarea{
            border:1px solid #d2d2d2;
        background-color:transparent;
        border-radius:5px;
        }
        select{
            border:1px solid #d2d2d2;
    background-color:transparent;
    border-radius:5px;
        }
        h2{
            color:skyblue;
            font-weight: bold;
        }
.btn1 {
   height:25px;
   color:lightskyblue;
   background-color:white;
    border-radius:5px;
    border:1px solid lightblue;
    font-size:large;
    padding:10 20px;
    cursor:pointer;
}
    </style>
</head>
<body>
    <div>
    <form action="./update-news.php" method="POST">
        <table border="0" align="center" cellpadding="10" cellspacing="10" style="font-size:large;">
            <tr>
                <td colspan="2" align="center"><h2>公告内容</h2></td>
            </tr>
            <tr>
                <td>通告标题:</td>
                <td><input required="required" type="text" size="46" name="news_title" value="<?php echo $rows['title']?>"></td>
                <!--除ie外，其他浏览器均支持number类型加减操作-->
            </tr>

            <tr>
                <td>通知类型:</td>
                <td>
                    <select name="news_class">
                        <option value="AA类通告">AA类通告</option>
                        <option value="BB类通告">BB类通告</option>
                        <option value="CC类通告">CC类通告</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td>信息来源</td>
                <td><input required="required" size="25" type="text" name="news_resource" value="<?php echo $rows['resource']?>"></td>
            </tr>

            <tr>
                <td>主体内容：</td>
                <td><textarea type="text" name="main_content" required="required" cols="80" rows="16" ><?php echo $rows['main_content']?></textarea></td>
            </tr>

            <tr>
                <td colspan="2" align="center">
                    <input type="submit" name="submit" value="修改" class="btn1" />
                    <input type="hidden" name="id" value="<?php echo $id?>">
                    &nbsp;&nbsp;
                </td>
            </tr>

        </table>

    </form>
    </div>
   
</body>
</html>