<?php
$id=$_POST['id'];
$news_title=$_POST['news_title'];
$news_class=$_POST['news_class'];
$news_resource=$_POST['news_resource'];
$main_content=$_POST['main_content'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');
$sql="UPDATE news set title='{$news_title}',news_class='{$news_class}',resource='{$news_resource}',main_content='{$main_content}' where id='{$id}'  ";
$res=mysql_query($sql);
if($res){
    echo "<script>alert('修改成功')</script>";
    echo "<script>setTimeout(function(){window.location.href='../lvji/lvji.php';},50);</script>";
}
?>