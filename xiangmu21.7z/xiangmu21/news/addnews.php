<?php
/*编辑公告通知

*标题、通知类型、信息来源、发布时间（自动获取？）、访问量（自动获取？）、主体内容、支持文档导入？
*上传图片或者其他附件，提供下载功能
*保存为草稿、直接发布
*每半小时自动刷新一次


*/
$news_title=$_POST['news_title'];
$news_class=$_POST['news_class'];
$news_resource=$_POST['news_resource'];
$main_content=$_POST['main_content'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');

$insert="INSERT news(title,news_class,resource,news_date,main_content) VALUES('{$news_title}','{$news_class}','{$news_resource}',now(),'{$main_content}')";
$execute=mysql_query($insert);
if($execute){
	echo "<script>alert('发布成功')</script>";
	echo "<script>
	setTimeout(function(){window.location.href='../lvji/lvji.php';},50);
	</script>";
}
?>