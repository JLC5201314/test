<?php
$id=$_GET['id'];
include_once "../connect.php";
// 作用, 链接数据库
connect_mysql();
mysql_select_db('news');
$sql="delete from news where id='{$id}'";
$res=mysql_query($sql);
if($res){
    echo "<script>alert('删除成功')</script>";
    echo "<script>setTimeout(function(){window.location.href='../lvji/lvji.php'},50);</script>";
}

?>